
% Program FPGA
disp('### Programming FPGA ');
filProgramFPGA('Xilinx Vivado','C:\Users\MAM\Desktop\2D_Filtering_FPGA\Sobel_filter_FPGA\codegen\mlhdlc_sobel\fil\mlhdlc_sobel_fixpt_fil\mlhdlc_sobel_fixpt_fil.bit',1);

disp('### Waiting for FPGA initialization ');
pause(3);
% Clear persistent variables before simulation
%l_clearPersistentVariable;

% Clear persistent variables after simulation
%onCleanupObj = onCleanup(@() l_clearPersistentVariable);

% Add current working directory to search path
savedPathVar = addpath(pwd);
restorePathObj = onCleanup(@() path(savedPathVar));

% Run generated test bench
disp('### Simulating generated test bench ');
% Exercise the compiled version of mlhdlc_sobel_wrapper_fixpt_fil in the generated test bench.
% To debug the test bench with the original function "mlhdlc_sobel_wrapper_fixpt_fil",
% replace the next line with "mlhdlc_sobel_tb_fil"
coder.runTest('localRunTest_mlhdlc_sobel_fixpt','mlhdlc_sobel_wrapper_fixpt_fil');
% To recompile MATLAB function "mlhdlc_sobel_wrapper_fixpt_fil",
% run the re-compilation function "localRecompile_mlhdlc_sobel_wrapper_fixpt_fil".
disp('### Finished Simulation');

% Plot logged output values
global gEMLSimLogRunIdx;
global gEMLSimLogVal_out_valid;
global gEMLSimLogVal_out_valid_d2;
figure;
hold on;
subplot(3,1,1);
plot(gEMLSimLogVal_out_valid(1:gEMLSimLogRunIdx-1,:),'b');
title('valid:fil','Interpreter','none')
subplot(3,1,2);
plot(gEMLSimLogVal_out_valid_d2(1:gEMLSimLogRunIdx-1,:),'r');
title('valid:Reference','Interpreter','none')
subplot(3,1,3);
plot(double(gEMLSimLogVal_out_valid(1:gEMLSimLogRunIdx-1,:)) - double(gEMLSimLogVal_out_valid_d2(1:gEMLSimLogRunIdx-1,:)),'m');
title('valid:Difference','Interpreter','none')
hold off;
global gEMLSimLogVal_out_ed;
global gEMLSimLogVal_out_ed_d2;
figure;
hold on;
subplot(3,1,1);
plot(gEMLSimLogVal_out_ed(1:gEMLSimLogRunIdx-1,:),'b');
title('ed:fil','Interpreter','none')
subplot(3,1,2);
plot(gEMLSimLogVal_out_ed_d2(1:gEMLSimLogRunIdx-1,:),'r');
title('ed:Reference','Interpreter','none')
subplot(3,1,3);
plot(double(gEMLSimLogVal_out_ed(1:gEMLSimLogRunIdx-1,:)) - double(gEMLSimLogVal_out_ed_d2(1:gEMLSimLogRunIdx-1,:)),'m');
title('ed:Difference','Interpreter','none')
hold off;
global gEMLSimLogVal_out_gh;
global gEMLSimLogVal_out_gh_d2;
figure;
hold on;
subplot(3,1,1);
plot(gEMLSimLogVal_out_gh(1:gEMLSimLogRunIdx-1,:),'b');
title('gh:fil','Interpreter','none')
subplot(3,1,2);
plot(gEMLSimLogVal_out_gh_d2(1:gEMLSimLogRunIdx-1,:),'r');
title('gh:Reference','Interpreter','none')
subplot(3,1,3);
plot(double(gEMLSimLogVal_out_gh(1:gEMLSimLogRunIdx-1,:)) - double(gEMLSimLogVal_out_gh_d2(1:gEMLSimLogRunIdx-1,:)),'m');
title('gh:Difference','Interpreter','none')
hold off;
global gEMLSimLogVal_out_gv;
global gEMLSimLogVal_out_gv_d2;
figure;
hold on;
subplot(3,1,1);
plot(gEMLSimLogVal_out_gv(1:gEMLSimLogRunIdx-1,:),'b');
title('gv:fil','Interpreter','none')
subplot(3,1,2);
plot(gEMLSimLogVal_out_gv_d2(1:gEMLSimLogRunIdx-1,:),'r');
title('gv:Reference','Interpreter','none')
subplot(3,1,3);
plot(double(gEMLSimLogVal_out_gv(1:gEMLSimLogRunIdx-1,:)) - double(gEMLSimLogVal_out_gv_d2(1:gEMLSimLogRunIdx-1,:)),'m');
title('gv:Difference','Interpreter','none')
hold off;

function l_clearPersistentVariable
% Clear reference DUT function
clear mlhdlc_sobel_fixpt;

% Clear FPGA-in-the-Loop System object wrapper function
clear mlhdlc_sobel_fixpt_sysobj_fil;

% Clear FPGA-in-the-Loop function
clear mlhdlc_sobel_fixpt_fil;

% Clear generated MEX function
clear mlhdlc_sobel_wrapper_fixpt_fil_mex

% Clear logged values
clear global gEMLSimLogRunIdx;
clear global gEMLSimLogVal_out_valid;
clear global gEMLSimLogVal_out_ed;
clear global gEMLSimLogVal_out_gh;
clear global gEMLSimLogVal_out_gv;
clear global gEMLSimLogVal_out_valid_d2;
clear global gEMLSimLogVal_out_ed_d2;
clear global gEMLSimLogVal_out_gh_d2;
clear global gEMLSimLogVal_out_gv_d2;
end