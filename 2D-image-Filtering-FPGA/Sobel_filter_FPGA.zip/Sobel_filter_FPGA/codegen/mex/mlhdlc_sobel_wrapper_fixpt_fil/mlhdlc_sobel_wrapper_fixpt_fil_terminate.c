/*
 * mlhdlc_sobel_wrapper_fixpt_fil_terminate.c
 *
 * Code generation for function 'mlhdlc_sobel_wrapper_fixpt_fil_terminate'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil_terminate.h"
#include "_coder_mlhdlc_sobel_wrapper_fixpt_fil_mex.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil_data.h"

/* Function Definitions */
void mlhdlc_sobel_wrapper_fixpt_fil_atexit(void)
{
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  mexFunctionCreateRootTLS();
  st.tls = emlrtRootTLSGlobal;
  emlrtEnterRtStackR2012b(&st);
  emlrtLeaveRtStackR2012b(&st);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
  emlrtDestroyArray(&delayobj_valid);
  emlrtDestroyArray(&delayobj_ed);
  emlrtDestroyArray(&delayobj_gh);
  emlrtDestroyArray(&delayobj_gv);
  emlrtDestroyArray(&eml_mx);
  emlrtDestroyArray(&b_eml_mx);
  emlrtDestroyArray(&c_eml_mx);
}

void mlhdlc_sobel_wrapper_fixpt_fil_terminate(void)
{
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  st.tls = emlrtRootTLSGlobal;
  emlrtLeaveRtStackR2012b(&st);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}

/* End of code generation (mlhdlc_sobel_wrapper_fixpt_fil_terminate.c) */
