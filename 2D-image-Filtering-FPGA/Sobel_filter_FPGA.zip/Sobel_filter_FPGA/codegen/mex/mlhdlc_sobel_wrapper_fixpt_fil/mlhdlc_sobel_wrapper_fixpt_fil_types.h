/*
 * mlhdlc_sobel_wrapper_fixpt_fil_types.h
 *
 * Code generation for function 'mlhdlc_sobel_wrapper_fixpt_fil'
 *
 */

#ifndef MLHDLC_SOBEL_WRAPPER_FIXPT_FIL_TYPES_H
#define MLHDLC_SOBEL_WRAPPER_FIXPT_FIL_TYPES_H

/* Include files */
#include "rtwtypes.h"
#endif

/* End of code generation (mlhdlc_sobel_wrapper_fixpt_fil_types.h) */
