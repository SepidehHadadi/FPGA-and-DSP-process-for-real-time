/*
 * _coder_mlhdlc_sobel_wrapper_fixpt_fil_api.c
 *
 * Code generation for function '_coder_mlhdlc_sobel_wrapper_fixpt_fil_api'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil.h"
#include "_coder_mlhdlc_sobel_wrapper_fixpt_fil_api.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil_mexutil.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil_data.h"

/* Function Declarations */
static real_T c_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  char_T *identifier);
static real_T d_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId);
static real_T f_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId);

/* Function Definitions */
static real_T c_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  char_T *identifier)
{
  real_T y;
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = (const char *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = d_emlrt_marshallIn(sp, emlrtAlias(u), &thisId);
  emlrtDestroyArray(&u);
  return y;
}

static real_T d_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId)
{
  real_T y;
  y = f_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static real_T f_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId)
{
  real_T ret;
  static const int32_T dims = 0;
  emlrtCheckBuiltInR2012b(sp, msgId, src, "double", false, 0U, &dims);
  ret = *(real_T *)mxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

void mlhdlc_sobel_wrapper_fixpt_fil_api(const mxArray * const prhs[1], const
  mxArray *plhs[4])
{
  real_T u;
  boolean_T valid;
  boolean_T ed;
  real_T gh;
  real_T gv;
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  st.tls = emlrtRootTLSGlobal;

  /* Marshall function inputs */
  u = c_emlrt_marshallIn(&st, emlrtAliasP(prhs[0]), "u");

  /* Invoke the target function */
  mlhdlc_sobel_wrapper_fixpt_fil(&st, u, &valid, &ed, &gh, &gv);

  /* Marshall function outputs */
  plhs[0] = b_emlrt_marshallOut(valid);
  plhs[1] = b_emlrt_marshallOut(ed);
  plhs[2] = emlrt_marshallOut(gh);
  plhs[3] = emlrt_marshallOut(gv);
}

/* End of code generation (_coder_mlhdlc_sobel_wrapper_fixpt_fil_api.c) */
