/*
 * _coder_mlhdlc_sobel_wrapper_fixpt_fil_api.h
 *
 * Code generation for function '_coder_mlhdlc_sobel_wrapper_fixpt_fil_api'
 *
 */

#ifndef _CODER_MLHDLC_SOBEL_WRAPPER_FIXPT_FIL_API_H
#define _CODER_MLHDLC_SOBEL_WRAPPER_FIXPT_FIL_API_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil_types.h"

/* Function Declarations */
extern void mlhdlc_sobel_wrapper_fixpt_fil_api(const mxArray * const prhs[1],
  const mxArray *plhs[4]);

#endif

/* End of code generation (_coder_mlhdlc_sobel_wrapper_fixpt_fil_api.h) */
