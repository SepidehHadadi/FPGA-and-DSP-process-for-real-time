/*
 * mlhdlc_sobel_fixpt_fil.h
 *
 * Code generation for function 'mlhdlc_sobel_fixpt_fil'
 *
 */

#ifndef MLHDLC_SOBEL_FIXPT_FIL_H
#define MLHDLC_SOBEL_FIXPT_FIL_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil_types.h"

/* Function Declarations */
extern void delayobj_ed_init(void);
extern void delayobj_gh_init(void);
extern void delayobj_gv_init(void);
extern void delayobj_valid_init(void);
extern void initialized_not_empty_init(void);
extern void mlhdlc_sobel_fixpt_fil_init(void);

#endif

/* End of code generation (mlhdlc_sobel_fixpt_fil.h) */
