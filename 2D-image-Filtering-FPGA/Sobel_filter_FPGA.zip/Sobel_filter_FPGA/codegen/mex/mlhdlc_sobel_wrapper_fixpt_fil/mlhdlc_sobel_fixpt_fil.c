/*
 * mlhdlc_sobel_fixpt_fil.c
 *
 * Code generation for function 'mlhdlc_sobel_fixpt_fil'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil.h"
#include "mlhdlc_sobel_fixpt_fil.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil_data.h"

/* Function Definitions */
void delayobj_ed_init(void)
{
  emlrtAssignP(&delayobj_ed, NULL);
}

void delayobj_gh_init(void)
{
  emlrtAssignP(&delayobj_gh, NULL);
}

void delayobj_gv_init(void)
{
  emlrtAssignP(&delayobj_gv, NULL);
}

void delayobj_valid_init(void)
{
  emlrtAssignP(&delayobj_valid, NULL);
}

void initialized_not_empty_init(void)
{
  initialized_not_empty = false;
}

void mlhdlc_sobel_fixpt_fil_init(void)
{
}

/* End of code generation (mlhdlc_sobel_fixpt_fil.c) */
