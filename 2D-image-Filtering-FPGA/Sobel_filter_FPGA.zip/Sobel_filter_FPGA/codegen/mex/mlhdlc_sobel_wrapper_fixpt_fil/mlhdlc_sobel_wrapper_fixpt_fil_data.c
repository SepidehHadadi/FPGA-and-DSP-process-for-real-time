/*
 * mlhdlc_sobel_wrapper_fixpt_fil_data.c
 *
 * Code generation for function 'mlhdlc_sobel_wrapper_fixpt_fil_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil_data.h"

/* Variable Definitions */
emlrtCTX emlrtRootTLSGlobal = NULL;
const volatile char_T *emlrtBreakCheckR2012bFlagVar = NULL;
boolean_T initialized_not_empty;
const mxArray *delayobj_valid;
const mxArray *delayobj_ed;
const mxArray *delayobj_gh;
const mxArray *delayobj_gv;
uint16_T cnt;
uint16_T u_d;
uint16_T b_u_d;
uint16_T c_u_d[80];
uint8_T ctr;
uint16_T d_u_d;
uint16_T e_u_d;
uint16_T f_u_d[80];
uint8_T b_ctr;
uint16_T g_u_d;
uint16_T h_u_d;
const mxArray *eml_mx;
const mxArray *b_eml_mx;
const mxArray *c_eml_mx;
emlrtContext emlrtContextGlobal = { true,/* bFirstTime */
  false,                               /* bInitialized */
  131450U,                             /* fVersionInfo */
  NULL,                                /* fErrorFunction */
  "mlhdlc_sobel_wrapper_fixpt_fil",    /* fFunctionName */
  NULL,                                /* fRTCallStack */
  false,                               /* bDebugMode */
  { 2045744189U, 2170104910U, 2743257031U, 4284093946U },/* fSigWrd */
  NULL                                 /* fSigMem */
};

emlrtRSInfo c_emlrtRSI = { 54,         /* lineNo */
  "mlhdlc_sobel_fixpt",                /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fixpt\\mlhdlc_sobel_fixpt.m"/* pathName */
};

emlrtRSInfo d_emlrtRSI = { 55,         /* lineNo */
  "mlhdlc_sobel_fixpt",                /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fixpt\\mlhdlc_sobel_fixpt.m"/* pathName */
};

emlrtRSInfo f_emlrtRSI = { 57,         /* lineNo */
  "mlhdlc_sobel_fixpt",                /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fixpt\\mlhdlc_sobel_fixpt.m"/* pathName */
};

emlrtRSInfo g_emlrtRSI = { 58,         /* lineNo */
  "mlhdlc_sobel_fixpt",                /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fixpt\\mlhdlc_sobel_fixpt.m"/* pathName */
};

emlrtRSInfo i_emlrtRSI = { 60,         /* lineNo */
  "mlhdlc_sobel_fixpt",                /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fixpt\\mlhdlc_sobel_fixpt.m"/* pathName */
};

emlrtRSInfo j_emlrtRSI = { 61,         /* lineNo */
  "mlhdlc_sobel_fixpt",                /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fixpt\\mlhdlc_sobel_fixpt.m"/* pathName */
};

/* End of code generation (mlhdlc_sobel_wrapper_fixpt_fil_data.c) */
