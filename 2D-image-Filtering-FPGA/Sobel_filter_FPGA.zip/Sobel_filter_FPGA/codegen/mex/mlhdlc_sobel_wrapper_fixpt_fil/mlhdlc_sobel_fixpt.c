/*
 * mlhdlc_sobel_fixpt.c
 *
 * Code generation for function 'mlhdlc_sobel_fixpt'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil.h"
#include "mlhdlc_sobel_fixpt.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil_data.h"

/* Function Definitions */
void b_ctr_not_empty_init(void)
{
}

void b_u_d_not_empty_init(void)
{
}

void c_u_d_not_empty_init(void)
{
}

void cnt_not_empty_init(void)
{
}

void ctr_not_empty_init(void)
{
}

void d_u_d_not_empty_init(void)
{
}

void e_u_d_not_empty_init(void)
{
}

void f_u_d_not_empty_init(void)
{
}

void filterdelay1_init(void)
{
  u_d = 0;
}

void filterdelay2_init(void)
{
  b_u_d = 0;
}

void filterdelay3_init(void)
{
  d_u_d = 0;
}

void filterdelay4_init(void)
{
  e_u_d = 0;
}

void filterdelay5_init(void)
{
  g_u_d = 0;
}

void filterdelay6_init(void)
{
  h_u_d = 0;
}

void g_u_d_not_empty_init(void)
{
}

void h_u_d_not_empty_init(void)
{
}

void line_buffer1_init(void)
{
  memset(&c_u_d[0], 0, 80U * sizeof(uint16_T));
  ctr = 1;
}

void line_buffer2_init(void)
{
  memset(&f_u_d[0], 0, 80U * sizeof(uint16_T));
  b_ctr = 1;
}

void mlhdlc_sobel_fixpt_init(void)
{
  cnt = 0;
}

void u_d_not_empty_init(void)
{
}

/* End of code generation (mlhdlc_sobel_fixpt.c) */
