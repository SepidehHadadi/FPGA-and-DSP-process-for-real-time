/*
 * mlhdlc_sobel_wrapper_fixpt_fil_mexutil.h
 *
 * Code generation for function 'mlhdlc_sobel_wrapper_fixpt_fil_mexutil'
 *
 */

#ifndef MLHDLC_SOBEL_WRAPPER_FIXPT_FIL_MEXUTIL_H
#define MLHDLC_SOBEL_WRAPPER_FIXPT_FIL_MEXUTIL_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil_types.h"

/* Function Declarations */
extern const mxArray *b_emlrt_marshallOut(const boolean_T u);
extern const mxArray *emlrt_marshallOut(const real_T u);

#endif

/* End of code generation (mlhdlc_sobel_wrapper_fixpt_fil_mexutil.h) */
