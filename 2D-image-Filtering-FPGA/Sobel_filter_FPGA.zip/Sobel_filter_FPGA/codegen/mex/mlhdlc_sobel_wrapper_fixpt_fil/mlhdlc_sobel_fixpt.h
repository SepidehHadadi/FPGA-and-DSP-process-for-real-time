/*
 * mlhdlc_sobel_fixpt.h
 *
 * Code generation for function 'mlhdlc_sobel_fixpt'
 *
 */

#ifndef MLHDLC_SOBEL_FIXPT_H
#define MLHDLC_SOBEL_FIXPT_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil_types.h"

/* Function Declarations */
extern void b_ctr_not_empty_init(void);
extern void b_u_d_not_empty_init(void);
extern void c_u_d_not_empty_init(void);
extern void cnt_not_empty_init(void);
extern void ctr_not_empty_init(void);
extern void d_u_d_not_empty_init(void);
extern void e_u_d_not_empty_init(void);
extern void f_u_d_not_empty_init(void);
extern void filterdelay1_init(void);
extern void filterdelay2_init(void);
extern void filterdelay3_init(void);
extern void filterdelay4_init(void);
extern void filterdelay5_init(void);
extern void filterdelay6_init(void);
extern void g_u_d_not_empty_init(void);
extern void h_u_d_not_empty_init(void);
extern void line_buffer1_init(void);
extern void line_buffer2_init(void);
extern void mlhdlc_sobel_fixpt_init(void);
extern void u_d_not_empty_init(void);

#endif

/* End of code generation (mlhdlc_sobel_fixpt.h) */
