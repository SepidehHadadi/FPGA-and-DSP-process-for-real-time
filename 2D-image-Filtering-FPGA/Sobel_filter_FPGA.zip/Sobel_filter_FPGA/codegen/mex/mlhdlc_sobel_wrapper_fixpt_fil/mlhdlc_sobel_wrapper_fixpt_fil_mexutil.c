/*
 * mlhdlc_sobel_wrapper_fixpt_fil_mexutil.c
 *
 * Code generation for function 'mlhdlc_sobel_wrapper_fixpt_fil_mexutil'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil_mexutil.h"

/* Function Definitions */
const mxArray *b_emlrt_marshallOut(const boolean_T u)
{
  const mxArray *y;
  const mxArray *m2;
  y = NULL;
  m2 = emlrtCreateLogicalScalar(u);
  emlrtAssign(&y, m2);
  return y;
}

const mxArray *emlrt_marshallOut(const real_T u)
{
  const mxArray *y;
  const mxArray *m1;
  y = NULL;
  m1 = emlrtCreateDoubleScalar(u);
  emlrtAssign(&y, m1);
  return y;
}

/* End of code generation (mlhdlc_sobel_wrapper_fixpt_fil_mexutil.c) */
