/*
 * mlhdlc_sobel_wrapper_fixpt_fil.c
 *
 * Code generation for function 'mlhdlc_sobel_wrapper_fixpt_fil'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil_mexutil.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil_data.h"

/* Variable Definitions */
static emlrtRSInfo emlrtRSI = { 9,     /* lineNo */
  "mlhdlc_sobel_wrapper_fixpt_fil",    /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_wrapper_fixpt_fil.m"/* pathName */
};

static emlrtRSInfo b_emlrtRSI = { 31,  /* lineNo */
  "mlhdlc_sobel_fixpt_fil",            /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pathName */
};

static emlrtRSInfo e_emlrtRSI = { 56,  /* lineNo */
  "mlhdlc_sobel_fixpt",                /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fixpt\\mlhdlc_sobel_fixpt.m"/* pathName */
};

static emlrtRSInfo h_emlrtRSI = { 59,  /* lineNo */
  "mlhdlc_sobel_fixpt",                /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fixpt\\mlhdlc_sobel_fixpt.m"/* pathName */
};

static emlrtMCInfo b_emlrtMCI = { 23,  /* lineNo */
  21,                                  /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtMCInfo c_emlrtMCI = { 23,  /* lineNo */
  4,                                   /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtMCInfo d_emlrtMCI = { 24,  /* lineNo */
  18,                                  /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtMCInfo e_emlrtMCI = { 24,  /* lineNo */
  4,                                   /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtMCInfo f_emlrtMCI = { 34,  /* lineNo */
  1,                                   /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtMCInfo g_emlrtMCI = { 25,  /* lineNo */
  18,                                  /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtMCInfo h_emlrtMCI = { 37,  /* lineNo */
  9,                                   /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtMCInfo i_emlrtMCI = { 25,  /* lineNo */
  4,                                   /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtMCInfo j_emlrtMCI = { 38,  /* lineNo */
  6,                                   /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtMCInfo k_emlrtMCI = { 26,  /* lineNo */
  18,                                  /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtMCInfo l_emlrtMCI = { 42,  /* lineNo */
  12,                                  /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtMCInfo m_emlrtMCI = { 26,  /* lineNo */
  4,                                   /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtMCInfo n_emlrtMCI = { 43,  /* lineNo */
  9,                                   /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtMCInfo o_emlrtMCI = { 44,  /* lineNo */
  9,                                   /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtMCInfo p_emlrtMCI = { 45,  /* lineNo */
  9,                                   /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtMCInfo q_emlrtMCI = { 48,  /* lineNo */
  1,                                   /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtMCInfo r_emlrtMCI = { 49,  /* lineNo */
  1,                                   /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtMCInfo s_emlrtMCI = { 50,  /* lineNo */
  1,                                   /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtMCInfo t_emlrtMCI = { 51,  /* lineNo */
  1,                                   /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtMCInfo u_emlrtMCI = { 54,  /* lineNo */
  1,                                   /* colNo */
  "mlhdlc_sobel_fixpt_fil",            /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pName */
};

static emlrtBCInfo emlrtBCI = { 1,     /* iFirst */
  80,                                  /* iLast */
  114,                                 /* lineNo */
  1,                                   /* colNo */
  "u_d",                               /* aName */
  "mlhdlc_sobel_fixpt",                /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fixpt\\mlhdlc_sobel_fixpt.m",/* pName */
  3                                    /* checkKind */
};

static emlrtBCInfo b_emlrtBCI = { 1,   /* iFirst */
  80,                                  /* iLast */
  155,                                 /* lineNo */
  1,                                   /* colNo */
  "u_d",                               /* aName */
  "mlhdlc_sobel_fixpt",                /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fixpt\\mlhdlc_sobel_fixpt.m",/* pName */
  3                                    /* checkKind */
};

static emlrtBCInfo c_emlrtBCI = { 1,   /* iFirst */
  80,                                  /* iLast */
  113,                                 /* lineNo */
  8,                                   /* colNo */
  "u_d",                               /* aName */
  "mlhdlc_sobel_fixpt",                /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fixpt\\mlhdlc_sobel_fixpt.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo d_emlrtBCI = { 1,   /* iFirst */
  80,                                  /* iLast */
  154,                                 /* lineNo */
  8,                                   /* colNo */
  "u_d",                               /* aName */
  "mlhdlc_sobel_fixpt",                /* fName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fixpt\\mlhdlc_sobel_fixpt.m",/* pName */
  0                                    /* checkKind */
};

static emlrtRSInfo k_emlrtRSI = { 26,  /* lineNo */
  "mlhdlc_sobel_fixpt_fil",            /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pathName */
};

static emlrtRSInfo l_emlrtRSI = { 25,  /* lineNo */
  "mlhdlc_sobel_fixpt_fil",            /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pathName */
};

static emlrtRSInfo m_emlrtRSI = { 24,  /* lineNo */
  "mlhdlc_sobel_fixpt_fil",            /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pathName */
};

static emlrtRSInfo n_emlrtRSI = { 23,  /* lineNo */
  "mlhdlc_sobel_fixpt_fil",            /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pathName */
};

static emlrtRSInfo o_emlrtRSI = { 34,  /* lineNo */
  "mlhdlc_sobel_fixpt_fil",            /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pathName */
};

static emlrtRSInfo p_emlrtRSI = { 38,  /* lineNo */
  "mlhdlc_sobel_fixpt_fil",            /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pathName */
};

static emlrtRSInfo q_emlrtRSI = { 37,  /* lineNo */
  "mlhdlc_sobel_fixpt_fil",            /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pathName */
};

static emlrtRSInfo r_emlrtRSI = { 45,  /* lineNo */
  "mlhdlc_sobel_fixpt_fil",            /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pathName */
};

static emlrtRSInfo s_emlrtRSI = { 44,  /* lineNo */
  "mlhdlc_sobel_fixpt_fil",            /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pathName */
};

static emlrtRSInfo t_emlrtRSI = { 43,  /* lineNo */
  "mlhdlc_sobel_fixpt_fil",            /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pathName */
};

static emlrtRSInfo u_emlrtRSI = { 42,  /* lineNo */
  "mlhdlc_sobel_fixpt_fil",            /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pathName */
};

static emlrtRSInfo v_emlrtRSI = { 51,  /* lineNo */
  "mlhdlc_sobel_fixpt_fil",            /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pathName */
};

static emlrtRSInfo w_emlrtRSI = { 50,  /* lineNo */
  "mlhdlc_sobel_fixpt_fil",            /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pathName */
};

static emlrtRSInfo x_emlrtRSI = { 49,  /* lineNo */
  "mlhdlc_sobel_fixpt_fil",            /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pathName */
};

static emlrtRSInfo y_emlrtRSI = { 48,  /* lineNo */
  "mlhdlc_sobel_fixpt_fil",            /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pathName */
};

static emlrtRSInfo ab_emlrtRSI = { 54, /* lineNo */
  "mlhdlc_sobel_fixpt_fil",            /* fcnName */
  "C:\\Users\\MAM\\Desktop\\2D_Filtering_FPGA\\Sobel_filter_FPGA\\codegen\\mlhdlc_sobel\\fil\\mlhdlc_sobel_fixpt_fil.m"/* pathName */
};

/* Function Declarations */
static boolean_T b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u,
  const emlrtMsgIdentifier *parentId);
static boolean_T e_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src,
  const emlrtMsgIdentifier *msgId);
static boolean_T emlrt_marshallIn(const emlrtStack *sp, const mxArray *b_isempty,
  const char_T *identifier);
static const mxArray *hdlverifier_Delay(const emlrtStack *sp, const mxArray *b,
  const mxArray *c, emlrtMCInfo *location);
static void hdlverifier_assert(const emlrtStack *sp, const mxArray *b, const
  mxArray *c, const mxArray *d, emlrtMCInfo *location);
static const mxArray *isempty(const emlrtStack *sp, const mxArray *b,
  emlrtMCInfo *location);
static void localLogData(const emlrtStack *sp, const mxArray *b, const mxArray
  *c, const mxArray *d, const mxArray *e, const mxArray *f, const mxArray *g,
  const mxArray *h, const mxArray *i, emlrtMCInfo *location);
static const mxArray *logical(const emlrtStack *sp, const mxArray *b,
  emlrtMCInfo *location);
static void mlhdlc_sobel_fixpt_sysobj_fil(const emlrtStack *sp, const mxArray *b,
  emlrtMCInfo *location, const mxArray **c, const mxArray **d, const mxArray **e,
  const mxArray **f);
static const mxArray *step(const emlrtStack *sp, const mxArray *b, const mxArray
  *c, emlrtMCInfo *location);

/* Function Definitions */
static boolean_T b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u,
  const emlrtMsgIdentifier *parentId)
{
  boolean_T y;
  y = e_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static boolean_T e_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src,
  const emlrtMsgIdentifier *msgId)
{
  boolean_T ret;
  static const int32_T dims = 0;
  emlrtCheckBuiltInR2012b(sp, msgId, src, "logical", false, 0U, &dims);
  ret = *mxGetLogicals(src);
  emlrtDestroyArray(&src);
  return ret;
}

static boolean_T emlrt_marshallIn(const emlrtStack *sp, const mxArray *b_isempty,
  const char_T *identifier)
{
  boolean_T y;
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = (const char *)identifier;
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = b_emlrt_marshallIn(sp, emlrtAlias(b_isempty), &thisId);
  emlrtDestroyArray(&b_isempty);
  return y;
}

static const mxArray *hdlverifier_Delay(const emlrtStack *sp, const mxArray *b,
  const mxArray *c, emlrtMCInfo *location)
{
  const mxArray *pArrays[2];
  const mxArray *m6;
  pArrays[0] = b;
  pArrays[1] = c;
  return emlrtCallMATLABR2012b(sp, 1, &m6, 2, pArrays, "hdlverifier.Delay", true,
    location);
}

static void hdlverifier_assert(const emlrtStack *sp, const mxArray *b, const
  mxArray *c, const mxArray *d, emlrtMCInfo *location)
{
  const mxArray *pArrays[3];
  pArrays[0] = b;
  pArrays[1] = c;
  pArrays[2] = d;
  emlrtCallMATLABR2012b(sp, 0, NULL, 3, pArrays, "hdlverifier.assert", true,
                        location);
}

static const mxArray *isempty(const emlrtStack *sp, const mxArray *b,
  emlrtMCInfo *location)
{
  const mxArray *pArray;
  const mxArray *m7;
  pArray = b;
  return emlrtCallMATLABR2012b(sp, 1, &m7, 1, &pArray, "isempty", true, location);
}

static void localLogData(const emlrtStack *sp, const mxArray *b, const mxArray
  *c, const mxArray *d, const mxArray *e, const mxArray *f, const mxArray *g,
  const mxArray *h, const mxArray *i, emlrtMCInfo *location)
{
  const mxArray *pArrays[8];
  pArrays[0] = b;
  pArrays[1] = c;
  pArrays[2] = d;
  pArrays[3] = e;
  pArrays[4] = f;
  pArrays[5] = g;
  pArrays[6] = h;
  pArrays[7] = i;
  emlrtCallMATLABR2012b(sp, 0, NULL, 8, pArrays, "localLogData", true, location);
}

static const mxArray *logical(const emlrtStack *sp, const mxArray *b,
  emlrtMCInfo *location)
{
  const mxArray *pArray;
  const mxArray *m8;
  pArray = b;
  return emlrtCallMATLABR2012b(sp, 1, &m8, 1, &pArray, "logical", true, location);
}

static void mlhdlc_sobel_fixpt_sysobj_fil(const emlrtStack *sp, const mxArray *b,
  emlrtMCInfo *location, const mxArray **c, const mxArray **d, const mxArray **e,
  const mxArray **f)
{
  const mxArray *pArray;
  const mxArray *mv0[4];
  pArray = b;
  emlrtAssign(c, emlrtCallMATLABR2012b(sp, 4, &mv0[0], 1, &pArray,
    "mlhdlc_sobel_fixpt_sysobj_fil", true, location));
  emlrtAssign(d, mv0[1]);
  emlrtAssign(e, mv0[2]);
  emlrtAssign(f, mv0[3]);
}

static const mxArray *step(const emlrtStack *sp, const mxArray *b, const mxArray
  *c, emlrtMCInfo *location)
{
  const mxArray *pArrays[2];
  const mxArray *m9;
  pArrays[0] = b;
  pArrays[1] = c;
  return emlrtCallMATLABR2012b(sp, 1, &m9, 2, pArrays, "step", true, location);
}

void mlhdlc_sobel_wrapper_fixpt_fil(const emlrtStack *sp, real_T u, boolean_T
  *valid, boolean_T *ed, real_T *gh, real_T *gv)
{
  real_T d0;
  uint16_T u_in;
  const mxArray *y;
  const mxArray *m0;
  static const int32_T iv0[2] = { 1, 6 };

  static const char_T b_u[6] = { 'L', 'e', 'n', 'g', 't', 'h' };

  static const int32_T iv1[2] = { 1, 6 };

  static const int32_T iv2[2] = { 1, 6 };

  static const int32_T iv3[2] = { 1, 6 };

  uint16_T b_y;
  uint16_T c_y;
  int32_T i0;
  uint16_T varargin_1;
  uint16_T d_y;
  uint16_T e_y;
  uint16_T b_varargin_1;
  uint16_T f_y;
  int32_T i1;
  int32_T i2;
  int32_T i3;
  int32_T i4;
  int32_T i5;
  int32_T i6;
  int32_T i7;
  int32_T i8;
  int16_T ref_gv;
  int16_T ref_gh;
  int32_T i9;
  int32_T i10;
  int32_T i11;
  int32_T i12;
  int32_T i13;
  int32_T i14;
  int32_T i15;
  int32_T i16;
  int32_T i17;
  int32_T i18;
  const mxArray *g_y;
  const mxArray *b_valid = NULL;
  const mxArray *b_ed = NULL;
  const mxArray *b_gh = NULL;
  const mxArray *b_gv = NULL;
  const mxArray *c_valid = NULL;
  const mxArray *c_ed = NULL;
  const mxArray *valid_d2 = NULL;
  const mxArray *ed_d2 = NULL;
  const mxArray *gh_d2 = NULL;
  const mxArray *gv_d2 = NULL;
  static const int32_T iv4[2] = { 1, 5 };

  static const char_T c_u[5] = { 'v', 'a', 'l', 'i', 'd' };

  static const int32_T iv5[2] = { 1, 2 };

  static const char_T d_u[2] = { 'e', 'd' };

  static const int32_T iv6[2] = { 1, 2 };

  static const char_T e_u[2] = { 'g', 'h' };

  static const int32_T iv7[2] = { 1, 2 };

  static const char_T f_u[2] = { 'g', 'v' };

  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*                                                                           % */
  /*            Generated by MATLAB 9.2 and Fixed-Point Designer 5.4           % */
  /*                                                                           % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  d0 = muDoubleScalarFloor(u * 64.0);
  if (muDoubleScalarIsNaN(d0) || muDoubleScalarIsInf(d0)) {
    d0 = 0.0;
  } else {
    d0 = muDoubleScalarRem(d0, 16384.0);
  }

  u_in = (uint16_T)((uint16_T)(int16_T)d0 & 16383);
  st.site = &emlrtRSI;

  /*  Auto generated function to simulate the generated HDL code using FPGA-in-the-Loop */
  /*   */
  /*  Generated by MATLAB 9.2 and HDL Coder 3.10 */
  /*  Declare persistent variables */
  /*  Initialize persistent variables */
  if (!initialized_not_empty) {
    initialized_not_empty = true;

    /*  Instantiate delay System object(s) */
    y = NULL;
    m0 = emlrtCreateCharArray(2, iv0);
    emlrtInitCharArrayR2013a(&st, 6, m0, &b_u[0]);
    emlrtAssign(&y, m0);
    b_st.site = &n_emlrtRSI;
    emlrtAssignP(&delayobj_valid, hdlverifier_Delay(&b_st, y, emlrt_marshallOut
      (2.0), &b_emlrtMCI));
    b_st.site = &n_emlrtRSI;
    emlrt_marshallIn(&b_st, isempty(&b_st, emlrtAliasP(delayobj_valid),
      &c_emlrtMCI), "isempty");
    y = NULL;
    m0 = emlrtCreateCharArray(2, iv1);
    emlrtInitCharArrayR2013a(&st, 6, m0, &b_u[0]);
    emlrtAssign(&y, m0);
    b_st.site = &m_emlrtRSI;
    emlrtAssignP(&delayobj_ed, hdlverifier_Delay(&b_st, y, emlrt_marshallOut(2.0),
      &d_emlrtMCI));
    b_st.site = &m_emlrtRSI;
    emlrt_marshallIn(&b_st, isempty(&b_st, emlrtAliasP(delayobj_ed), &e_emlrtMCI),
                     "isempty");
    y = NULL;
    m0 = emlrtCreateCharArray(2, iv2);
    emlrtInitCharArrayR2013a(&st, 6, m0, &b_u[0]);
    emlrtAssign(&y, m0);
    b_st.site = &l_emlrtRSI;
    emlrtAssignP(&delayobj_gh, hdlverifier_Delay(&b_st, y, emlrt_marshallOut(2.0),
      &g_emlrtMCI));
    b_st.site = &l_emlrtRSI;
    emlrt_marshallIn(&b_st, isempty(&b_st, emlrtAliasP(delayobj_gh), &i_emlrtMCI),
                     "isempty");
    y = NULL;
    m0 = emlrtCreateCharArray(2, iv3);
    emlrtInitCharArrayR2013a(&st, 6, m0, &b_u[0]);
    emlrtAssign(&y, m0);
    b_st.site = &k_emlrtRSI;
    emlrtAssignP(&delayobj_gv, hdlverifier_Delay(&b_st, y, emlrt_marshallOut(2.0),
      &k_emlrtMCI));
    b_st.site = &k_emlrtRSI;
    emlrt_marshallIn(&b_st, isempty(&b_st, emlrtAliasP(delayobj_gv), &m_emlrtMCI),
                     "isempty");
  }

  /*  Call the original MATLAB function to get reference signal */
  b_st.site = &b_emlrtRSI;

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*                                                                           % */
  /*            Generated by MATLAB 9.2 and Fixed-Point Designer 5.4           % */
  /*                                                                           % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Sobel Edge Detection */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  This example shows how to generate HDL code from MATLAB(R) design */
  /*  implementing the Sobel edge detection algorithm. The Sobel algorithm is */
  /*  implemented by the following steps. */
  /*   */
  /*  1. Compute the horizontal and vertical gradients, gh and gv, by */
  /*     convolving the image with the Sobel kernel and its transpose. */
  /*       Sobel kernel = [ 1  2  1; */
  /*                        0  0  0; */
  /*                       -1 -2 -1 ]; */
  /*  2. Compute the gradient of each pixel, g, which is the magnitude of the */
  /*     horizontal and vertical gradients. */
  /*       g = sqrt( gx.^2 + gy.^2 ) */
  /*  3. If the gradient is greater than the threshold, the pixel is */
  /*     considered as an edge pixel. */
  /*  */
  /*  Because the Sobel algorithm includes the convolution of the image with a */
  /*  3-by-3 window, the output will be delayed by a column plus one pixels. */
  /*  For example, the algorithm will output the edge for location (2,2) when */
  /*  it receives the pixel at location (1,1). */
  /*   */
  /*  Note: To simplify design, this example does not have special handling for */
  /*  the image border. Therefore, the border of the output is invalid. */
  /*  Copyright 2011-2015 The MathWorks, Inc. */
  /*  Determine whether the output is valid or not. */
  cnt = (uint16_T)((int32_T)((cnt & 16383) + 1U) & 8191);
  if ((cnt > 81) && (cnt <= 6481)) {
    *valid = true;
  } else {
    *valid = false;
  }

  /*  Delay the input pixel in order to have the pixels in a 3-by-3 window */
  /*  centering at the current output location. Let the location for the */
  /*  current output pixel be Icc, the pixels in the window are presented as */
  /*  follows. */
  /*    [ Ilt  Ict  Irt; */
  /*      Ilc  Icc  Irc; */
  /*      Ilb  Icb  Irb ] */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Delay: Delay the image by a pixel. */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  b_y = u_d;
  u_d = u_in;
  c_y = b_u_d;
  b_u_d = b_y;
  c_st.site = &e_emlrtRSI;

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Line buffer: Delay the image by a column (80 pixels) */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  i0 = ctr;
  if (!((i0 >= 1) && (i0 <= 80))) {
    emlrtDynamicBoundsCheckR2012b(i0, 1, 80, &c_emlrtBCI, &c_st);
  }

  varargin_1 = c_u_d[i0 - 1];
  i0 = ctr;
  if (!((i0 >= 1) && (i0 <= 80))) {
    emlrtDynamicBoundsCheckR2012b(i0, 1, 80, &emlrtBCI, &c_st);
  }

  c_u_d[i0 - 1] = u_in;
  if (ctr == 80) {
    ctr = 1;
  } else {
    ctr = (uint8_T)((uint8_T)(ctr + 1U) & 127);
  }

  d_y = d_u_d;
  d_u_d = varargin_1;
  e_y = e_u_d;
  e_u_d = d_y;
  c_st.site = &h_emlrtRSI;
  i0 = b_ctr;
  if (!((i0 >= 1) && (i0 <= 80))) {
    emlrtDynamicBoundsCheckR2012b(i0, 1, 80, &d_emlrtBCI, &c_st);
  }

  b_varargin_1 = f_u_d[i0 - 1];
  i0 = b_ctr;
  if (!((i0 >= 1) && (i0 <= 80))) {
    emlrtDynamicBoundsCheckR2012b(i0, 1, 80, &b_emlrtBCI, &c_st);
  }

  f_u_d[i0 - 1] = varargin_1;
  if (b_ctr == 80) {
    b_ctr = 1;
  } else {
    b_ctr = (uint8_T)((uint8_T)(b_ctr + 1U) & 127);
  }

  d_y = g_u_d;
  g_u_d = b_varargin_1;
  f_y = h_u_d;
  h_u_d = d_y;

  /*  Compute the horizontal and vertical gradients. */
  i0 = (int32_T)(((uint32_T)f_y + (uint16_T)(e_y << 1)) + c_y);
  i1 = b_varargin_1;
  if ((i0 & 1048576) != 0) {
    i2 = i0 | -1048576;
  } else {
    i2 = i0;
  }

  if ((i1 & 1048576) != 0) {
    i3 = i1 | -1048576;
  } else {
    i3 = i1;
  }

  i0 = i2 - i3;
  if ((i0 & 1048576) != 0) {
    i0 |= -1048576;
  } else {
    i0 &= 1048575;
  }

  i1 = (uint16_T)(varargin_1 << 1);
  if ((i0 & 4194304) != 0) {
    i4 = i0 | -4194304;
  } else {
    i4 = i0 & 4194303;
  }

  if ((i1 & 4194304) != 0) {
    i5 = i1 | -4194304;
  } else {
    i5 = i1;
  }

  i0 = i4 - i5;
  if ((i0 & 4194304) != 0) {
    i0 |= -4194304;
  } else {
    i0 &= 4194303;
  }

  i1 = u_in;
  if ((i0 & 16777216) != 0) {
    i6 = i0 | -16777216;
  } else {
    i6 = i0 & 16777215;
  }

  if ((i1 & 16777216) != 0) {
    i7 = i1 | -16777216;
  } else {
    i7 = i1;
  }

  i0 = i6 - i7;
  if ((i0 & 16777216) != 0) {
    i8 = i0 | -16777216;
  } else {
    i8 = i0 & 16777215;
  }

  ref_gv = (int16_T)(i8 >> 3);
  if ((ref_gv & 8192) != 0) {
    ref_gh = (int16_T)(ref_gv | -8192);
  } else {
    ref_gh = (int16_T)(ref_gv & 8191);
  }

  i0 = (int32_T)(((uint32_T)f_y + (uint16_T)(d_y << 1)) + b_varargin_1);
  i1 = c_y;
  if ((i0 & 1048576) != 0) {
    i9 = i0 | -1048576;
  } else {
    i9 = i0;
  }

  if ((i1 & 1048576) != 0) {
    i10 = i1 | -1048576;
  } else {
    i10 = i1;
  }

  i0 = i9 - i10;
  if ((i0 & 1048576) != 0) {
    i0 |= -1048576;
  } else {
    i0 &= 1048575;
  }

  i1 = (uint16_T)(b_y << 1);
  if ((i0 & 4194304) != 0) {
    i11 = i0 | -4194304;
  } else {
    i11 = i0 & 4194303;
  }

  if ((i1 & 4194304) != 0) {
    i12 = i1 | -4194304;
  } else {
    i12 = i1;
  }

  i0 = i11 - i12;
  if ((i0 & 4194304) != 0) {
    i0 |= -4194304;
  } else {
    i0 &= 4194303;
  }

  i1 = u_in;
  if ((i0 & 16777216) != 0) {
    i13 = i0 | -16777216;
  } else {
    i13 = i0 & 16777215;
  }

  if ((i1 & 16777216) != 0) {
    i14 = i1 | -16777216;
  } else {
    i14 = i1;
  }

  i0 = i13 - i14;
  if ((i0 & 16777216) != 0) {
    i15 = i0 | -16777216;
  } else {
    i15 = i0 & 16777215;
  }

  ref_gv = (int16_T)(i15 >> 3);
  if ((ref_gv & 8192) != 0) {
    ref_gv |= -8192;
  } else {
    ref_gv &= 8191;
  }

  /*  Compute the square of gradient. */
  /*  Determine whether a pixel is on the edge or not. */
  i0 = ref_gh * ref_gh;
  if ((i0 & 134217728) != 0) {
    i0 |= -134217728;
  } else {
    i0 &= 134217727;
  }

  i1 = ref_gv * ref_gv;
  if ((i1 & 134217728) != 0) {
    i1 |= -134217728;
  } else {
    i1 &= 134217727;
  }

  if ((i0 & 268435456) != 0) {
    i16 = i0 | -268435456;
  } else {
    i16 = i0 & 268435455;
  }

  if ((i1 & 268435456) != 0) {
    i17 = i1 | -268435456;
  } else {
    i17 = i1 & 268435455;
  }

  i0 = i16 + i17;
  if ((i0 & 268435456) != 0) {
    i18 = i0 | -268435456;
  } else {
    i18 = i0 & 268435455;
  }

  *ed = (((uint16_T)(i18 >> 13) & 16383) > 512);

  /*  Run FPGA-in-the-Loop */
  y = NULL;
  g_y = NULL;
  m0 = emlrtCreateNumericMatrix(1, 1, mxUINT16_CLASS, mxREAL);
  *(uint16_T *)mxGetData(m0) = u_in;
  emlrtAssign(&g_y, m0);
  emlrtAssign(&y, emlrtCreateFIR2013b(&st, eml_mx, b_eml_mx, "simulinkarray",
    g_y, true, false));
  b_st.site = &o_emlrtRSI;
  mlhdlc_sobel_fixpt_sysobj_fil(&b_st, y, &f_emlrtMCI, &b_valid, &b_ed, &b_gh,
    &b_gv);

  /*  Convert output signals */
  b_st.site = &q_emlrtRSI;
  emlrtAssign(&c_valid, logical(&b_st, emlrtAlias(b_valid), &h_emlrtMCI));
  b_st.site = &p_emlrtRSI;
  emlrtAssign(&c_ed, logical(&b_st, emlrtAlias(b_ed), &j_emlrtMCI));

  /*  Delay reference signal */
  b_st.site = &u_emlrtRSI;
  emlrtAssign(&valid_d2, step(&b_st, emlrtAliasP(delayobj_valid),
    b_emlrt_marshallOut(*valid), &l_emlrtMCI));
  b_st.site = &t_emlrtRSI;
  emlrtAssign(&ed_d2, step(&b_st, emlrtAliasP(delayobj_ed), b_emlrt_marshallOut(*
    ed), &n_emlrtMCI));
  y = NULL;
  g_y = NULL;
  m0 = emlrtCreateNumericMatrix(1, 1, mxINT16_CLASS, mxREAL);
  *(int16_T *)mxGetData(m0) = ref_gh;
  emlrtAssign(&g_y, m0);
  emlrtAssign(&y, emlrtCreateFIR2013b(&st, eml_mx, c_eml_mx, "simulinkarray",
    g_y, true, false));
  b_st.site = &s_emlrtRSI;
  emlrtAssign(&gh_d2, step(&b_st, emlrtAliasP(delayobj_gh), y, &o_emlrtMCI));
  y = NULL;
  g_y = NULL;
  m0 = emlrtCreateNumericMatrix(1, 1, mxINT16_CLASS, mxREAL);
  *(int16_T *)mxGetData(m0) = ref_gv;
  emlrtAssign(&g_y, m0);
  emlrtAssign(&y, emlrtCreateFIR2013b(&st, eml_mx, c_eml_mx, "simulinkarray",
    g_y, true, false));
  b_st.site = &r_emlrtRSI;
  emlrtAssign(&gv_d2, step(&b_st, emlrtAliasP(delayobj_gv), y, &p_emlrtMCI));

  /*  Verify the FPGA-in-the-Loop output */
  y = NULL;
  m0 = emlrtCreateCharArray(2, iv4);
  emlrtInitCharArrayR2013a(&st, 5, m0, &c_u[0]);
  emlrtAssign(&y, m0);
  b_st.site = &y_emlrtRSI;
  hdlverifier_assert(&b_st, emlrtAlias(c_valid), emlrtAlias(valid_d2), y,
                     &q_emlrtMCI);
  y = NULL;
  m0 = emlrtCreateCharArray(2, iv5);
  emlrtInitCharArrayR2013a(&st, 2, m0, &d_u[0]);
  emlrtAssign(&y, m0);
  b_st.site = &x_emlrtRSI;
  hdlverifier_assert(&b_st, emlrtAlias(c_ed), emlrtAlias(ed_d2), y, &r_emlrtMCI);
  y = NULL;
  m0 = emlrtCreateCharArray(2, iv6);
  emlrtInitCharArrayR2013a(&st, 2, m0, &e_u[0]);
  emlrtAssign(&y, m0);
  b_st.site = &w_emlrtRSI;
  hdlverifier_assert(&b_st, emlrtAlias(b_gh), emlrtAlias(gh_d2), y, &s_emlrtMCI);
  y = NULL;
  m0 = emlrtCreateCharArray(2, iv7);
  emlrtInitCharArrayR2013a(&st, 2, m0, &f_u[0]);
  emlrtAssign(&y, m0);
  b_st.site = &v_emlrtRSI;
  hdlverifier_assert(&b_st, emlrtAlias(b_gv), emlrtAlias(gv_d2), y, &t_emlrtMCI);
  b_st.site = &ab_emlrtRSI;
  localLogData(&b_st, emlrtAlias(c_valid), emlrtAlias(c_ed), emlrtAlias(b_gh),
               emlrtAlias(b_gv), emlrtAlias(valid_d2), emlrtAlias(ed_d2),
               emlrtAlias(gh_d2), emlrtAlias(gv_d2), &u_emlrtMCI);
  emlrtDestroyArray(&c_valid);
  emlrtDestroyArray(&c_ed);
  emlrtDestroyArray(&valid_d2);
  emlrtDestroyArray(&ed_d2);
  emlrtDestroyArray(&gh_d2);
  emlrtDestroyArray(&gv_d2);
  emlrtDestroyArray(&b_valid);
  emlrtDestroyArray(&b_ed);
  emlrtDestroyArray(&b_gh);
  emlrtDestroyArray(&b_gv);
  *gh = (real_T)ref_gh * 0.125;
  *gv = (real_T)ref_gv * 0.125;
}

/* End of code generation (mlhdlc_sobel_wrapper_fixpt_fil.c) */
