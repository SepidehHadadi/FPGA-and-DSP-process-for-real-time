/*
 * mlhdlc_sobel_wrapper_fixpt_fil.h
 *
 * Code generation for function 'mlhdlc_sobel_wrapper_fixpt_fil'
 *
 */

#ifndef MLHDLC_SOBEL_WRAPPER_FIXPT_FIL_H
#define MLHDLC_SOBEL_WRAPPER_FIXPT_FIL_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil_types.h"

/* Function Declarations */
extern void mlhdlc_sobel_wrapper_fixpt_fil(const emlrtStack *sp, real_T u,
  boolean_T *valid, boolean_T *ed, real_T *gh, real_T *gv);

#endif

/* End of code generation (mlhdlc_sobel_wrapper_fixpt_fil.h) */
