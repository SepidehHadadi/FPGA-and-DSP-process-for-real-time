/*
 * mlhdlc_sobel_wrapper_fixpt_fil_data.h
 *
 * Code generation for function 'mlhdlc_sobel_wrapper_fixpt_fil_data'
 *
 */

#ifndef MLHDLC_SOBEL_WRAPPER_FIXPT_FIL_DATA_H
#define MLHDLC_SOBEL_WRAPPER_FIXPT_FIL_DATA_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "mlhdlc_sobel_wrapper_fixpt_fil_types.h"

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern const volatile char_T *emlrtBreakCheckR2012bFlagVar;
extern boolean_T initialized_not_empty;
extern const mxArray *delayobj_valid;
extern const mxArray *delayobj_ed;
extern const mxArray *delayobj_gh;
extern const mxArray *delayobj_gv;
extern uint16_T cnt;
extern uint16_T u_d;
extern uint16_T b_u_d;
extern uint16_T c_u_d[80];
extern uint8_T ctr;
extern uint16_T d_u_d;
extern uint16_T e_u_d;
extern uint16_T f_u_d[80];
extern uint8_T b_ctr;
extern uint16_T g_u_d;
extern uint16_T h_u_d;
extern const mxArray *eml_mx;
extern const mxArray *b_eml_mx;
extern const mxArray *c_eml_mx;
extern emlrtContext emlrtContextGlobal;
extern emlrtRSInfo c_emlrtRSI;
extern emlrtRSInfo d_emlrtRSI;
extern emlrtRSInfo f_emlrtRSI;
extern emlrtRSInfo g_emlrtRSI;
extern emlrtRSInfo i_emlrtRSI;
extern emlrtRSInfo j_emlrtRSI;

#endif

/* End of code generation (mlhdlc_sobel_wrapper_fixpt_fil_data.h) */
