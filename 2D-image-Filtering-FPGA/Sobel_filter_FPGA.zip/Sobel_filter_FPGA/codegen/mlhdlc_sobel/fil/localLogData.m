function localLogData(out_valid, out_ed, out_gh, out_gv, out_valid_d2, out_ed_d2, out_gh_d2, out_gv_d2)
global gEMLSimLogVal_out_valid;
global gEMLSimLogVal_out_ed;
global gEMLSimLogVal_out_gh;
global gEMLSimLogVal_out_gv;
global gEMLSimLogVal_out_valid_d2;
global gEMLSimLogVal_out_ed_d2;
global gEMLSimLogVal_out_gh_d2;
global gEMLSimLogVal_out_gv_d2;
global gEMLSimLogRunIdx;
persistent maxIdx;

if isempty(gEMLSimLogRunIdx)
	gEMLSimLogRunIdx = 1;
	maxIdx = 1;
	if isstruct(out_valid)
		gEMLSimLogVal_out_valid = out_valid;
	elseif isscalar(out_valid)
		gEMLSimLogVal_out_valid = out_valid;
	elseif iscolumn(out_valid)
		gEMLSimLogVal_out_valid = out_valid.';
	elseif isrow(out_valid)
		gEMLSimLogVal_out_valid = out_valid;
	else
		gEMLSimLogVal_out_valid = {out_valid};
	end

	if isstruct(out_ed)
		gEMLSimLogVal_out_ed = out_ed;
	elseif isscalar(out_ed)
		gEMLSimLogVal_out_ed = out_ed;
	elseif iscolumn(out_ed)
		gEMLSimLogVal_out_ed = out_ed.';
	elseif isrow(out_ed)
		gEMLSimLogVal_out_ed = out_ed;
	else
		gEMLSimLogVal_out_ed = {out_ed};
	end

	if isstruct(out_gh)
		gEMLSimLogVal_out_gh = out_gh;
	elseif isscalar(out_gh)
		gEMLSimLogVal_out_gh = out_gh;
	elseif iscolumn(out_gh)
		gEMLSimLogVal_out_gh = out_gh.';
	elseif isrow(out_gh)
		gEMLSimLogVal_out_gh = out_gh;
	else
		gEMLSimLogVal_out_gh = {out_gh};
	end

	if isstruct(out_gv)
		gEMLSimLogVal_out_gv = out_gv;
	elseif isscalar(out_gv)
		gEMLSimLogVal_out_gv = out_gv;
	elseif iscolumn(out_gv)
		gEMLSimLogVal_out_gv = out_gv.';
	elseif isrow(out_gv)
		gEMLSimLogVal_out_gv = out_gv;
	else
		gEMLSimLogVal_out_gv = {out_gv};
	end

	if isstruct(out_valid_d2)
		gEMLSimLogVal_out_valid_d2 = out_valid_d2;
	elseif isscalar(out_valid_d2)
		gEMLSimLogVal_out_valid_d2 = out_valid_d2;
	elseif iscolumn(out_valid_d2)
		gEMLSimLogVal_out_valid_d2 = out_valid_d2.';
	elseif isrow(out_valid_d2)
		gEMLSimLogVal_out_valid_d2 = out_valid_d2;
	else
		gEMLSimLogVal_out_valid_d2 = {out_valid_d2};
	end

	if isstruct(out_ed_d2)
		gEMLSimLogVal_out_ed_d2 = out_ed_d2;
	elseif isscalar(out_ed_d2)
		gEMLSimLogVal_out_ed_d2 = out_ed_d2;
	elseif iscolumn(out_ed_d2)
		gEMLSimLogVal_out_ed_d2 = out_ed_d2.';
	elseif isrow(out_ed_d2)
		gEMLSimLogVal_out_ed_d2 = out_ed_d2;
	else
		gEMLSimLogVal_out_ed_d2 = {out_ed_d2};
	end

	if isstruct(out_gh_d2)
		gEMLSimLogVal_out_gh_d2 = out_gh_d2;
	elseif isscalar(out_gh_d2)
		gEMLSimLogVal_out_gh_d2 = out_gh_d2;
	elseif iscolumn(out_gh_d2)
		gEMLSimLogVal_out_gh_d2 = out_gh_d2.';
	elseif isrow(out_gh_d2)
		gEMLSimLogVal_out_gh_d2 = out_gh_d2;
	else
		gEMLSimLogVal_out_gh_d2 = {out_gh_d2};
	end

	if isstruct(out_gv_d2)
		gEMLSimLogVal_out_gv_d2 = out_gv_d2;
	elseif isscalar(out_gv_d2)
		gEMLSimLogVal_out_gv_d2 = out_gv_d2;
	elseif iscolumn(out_gv_d2)
		gEMLSimLogVal_out_gv_d2 = out_gv_d2.';
	elseif isrow(out_gv_d2)
		gEMLSimLogVal_out_gv_d2 = out_gv_d2;
	else
		gEMLSimLogVal_out_gv_d2 = {out_gv_d2};
	end

	gEMLSimLogRunIdx = gEMLSimLogRunIdx+1;
	return

end

if gEMLSimLogRunIdx > maxIdx
	maxIdx = 2 * maxIdx;
	if(iscell(gEMLSimLogVal_out_valid))
		gEMLSimLogVal_out_valid(maxIdx, :) = {gEMLSimLogVal_out_valid{1}};
	else
		gEMLSimLogVal_out_valid(maxIdx, :) = gEMLSimLogVal_out_valid(1);
	end
	if(iscell(gEMLSimLogVal_out_ed))
		gEMLSimLogVal_out_ed(maxIdx, :) = {gEMLSimLogVal_out_ed{1}};
	else
		gEMLSimLogVal_out_ed(maxIdx, :) = gEMLSimLogVal_out_ed(1);
	end
	if(iscell(gEMLSimLogVal_out_gh))
		gEMLSimLogVal_out_gh(maxIdx, :) = {gEMLSimLogVal_out_gh{1}};
	else
		gEMLSimLogVal_out_gh(maxIdx, :) = gEMLSimLogVal_out_gh(1);
	end
	if(iscell(gEMLSimLogVal_out_gv))
		gEMLSimLogVal_out_gv(maxIdx, :) = {gEMLSimLogVal_out_gv{1}};
	else
		gEMLSimLogVal_out_gv(maxIdx, :) = gEMLSimLogVal_out_gv(1);
	end
	if(iscell(gEMLSimLogVal_out_valid_d2))
		gEMLSimLogVal_out_valid_d2(maxIdx, :) = {gEMLSimLogVal_out_valid_d2{1}};
	else
		gEMLSimLogVal_out_valid_d2(maxIdx, :) = gEMLSimLogVal_out_valid_d2(1);
	end
	if(iscell(gEMLSimLogVal_out_ed_d2))
		gEMLSimLogVal_out_ed_d2(maxIdx, :) = {gEMLSimLogVal_out_ed_d2{1}};
	else
		gEMLSimLogVal_out_ed_d2(maxIdx, :) = gEMLSimLogVal_out_ed_d2(1);
	end
	if(iscell(gEMLSimLogVal_out_gh_d2))
		gEMLSimLogVal_out_gh_d2(maxIdx, :) = {gEMLSimLogVal_out_gh_d2{1}};
	else
		gEMLSimLogVal_out_gh_d2(maxIdx, :) = gEMLSimLogVal_out_gh_d2(1);
	end
	if(iscell(gEMLSimLogVal_out_gv_d2))
		gEMLSimLogVal_out_gv_d2(maxIdx, :) = {gEMLSimLogVal_out_gv_d2{1}};
	else
		gEMLSimLogVal_out_gv_d2(maxIdx, :) = gEMLSimLogVal_out_gv_d2(1);
	end
end

if isstruct(out_valid)
	gEMLSimLogVal_out_valid(gEMLSimLogRunIdx, :) = out_valid;
elseif isscalar(out_valid)
	gEMLSimLogVal_out_valid(gEMLSimLogRunIdx, :) = out_valid;
elseif iscolumn(out_valid)
	gEMLSimLogVal_out_valid(gEMLSimLogRunIdx, :) = out_valid.';
elseif(isrow(out_valid))
	gEMLSimLogVal_out_valid(gEMLSimLogRunIdx, :) = out_valid;
else
	gEMLSimLogVal_out_valid(gEMLSimLogRunIdx, :) = {out_valid};
end

if isstruct(out_ed)
	gEMLSimLogVal_out_ed(gEMLSimLogRunIdx, :) = out_ed;
elseif isscalar(out_ed)
	gEMLSimLogVal_out_ed(gEMLSimLogRunIdx, :) = out_ed;
elseif iscolumn(out_ed)
	gEMLSimLogVal_out_ed(gEMLSimLogRunIdx, :) = out_ed.';
elseif(isrow(out_ed))
	gEMLSimLogVal_out_ed(gEMLSimLogRunIdx, :) = out_ed;
else
	gEMLSimLogVal_out_ed(gEMLSimLogRunIdx, :) = {out_ed};
end

if isstruct(out_gh)
	gEMLSimLogVal_out_gh(gEMLSimLogRunIdx, :) = out_gh;
elseif isscalar(out_gh)
	gEMLSimLogVal_out_gh(gEMLSimLogRunIdx, :) = out_gh;
elseif iscolumn(out_gh)
	gEMLSimLogVal_out_gh(gEMLSimLogRunIdx, :) = out_gh.';
elseif(isrow(out_gh))
	gEMLSimLogVal_out_gh(gEMLSimLogRunIdx, :) = out_gh;
else
	gEMLSimLogVal_out_gh(gEMLSimLogRunIdx, :) = {out_gh};
end

if isstruct(out_gv)
	gEMLSimLogVal_out_gv(gEMLSimLogRunIdx, :) = out_gv;
elseif isscalar(out_gv)
	gEMLSimLogVal_out_gv(gEMLSimLogRunIdx, :) = out_gv;
elseif iscolumn(out_gv)
	gEMLSimLogVal_out_gv(gEMLSimLogRunIdx, :) = out_gv.';
elseif(isrow(out_gv))
	gEMLSimLogVal_out_gv(gEMLSimLogRunIdx, :) = out_gv;
else
	gEMLSimLogVal_out_gv(gEMLSimLogRunIdx, :) = {out_gv};
end

if isstruct(out_valid_d2)
	gEMLSimLogVal_out_valid_d2(gEMLSimLogRunIdx, :) = out_valid_d2;
elseif isscalar(out_valid_d2)
	gEMLSimLogVal_out_valid_d2(gEMLSimLogRunIdx, :) = out_valid_d2;
elseif iscolumn(out_valid_d2)
	gEMLSimLogVal_out_valid_d2(gEMLSimLogRunIdx, :) = out_valid_d2.';
elseif(isrow(out_valid_d2))
	gEMLSimLogVal_out_valid_d2(gEMLSimLogRunIdx, :) = out_valid_d2;
else
	gEMLSimLogVal_out_valid_d2(gEMLSimLogRunIdx, :) = {out_valid_d2};
end

if isstruct(out_ed_d2)
	gEMLSimLogVal_out_ed_d2(gEMLSimLogRunIdx, :) = out_ed_d2;
elseif isscalar(out_ed_d2)
	gEMLSimLogVal_out_ed_d2(gEMLSimLogRunIdx, :) = out_ed_d2;
elseif iscolumn(out_ed_d2)
	gEMLSimLogVal_out_ed_d2(gEMLSimLogRunIdx, :) = out_ed_d2.';
elseif(isrow(out_ed_d2))
	gEMLSimLogVal_out_ed_d2(gEMLSimLogRunIdx, :) = out_ed_d2;
else
	gEMLSimLogVal_out_ed_d2(gEMLSimLogRunIdx, :) = {out_ed_d2};
end

if isstruct(out_gh_d2)
	gEMLSimLogVal_out_gh_d2(gEMLSimLogRunIdx, :) = out_gh_d2;
elseif isscalar(out_gh_d2)
	gEMLSimLogVal_out_gh_d2(gEMLSimLogRunIdx, :) = out_gh_d2;
elseif iscolumn(out_gh_d2)
	gEMLSimLogVal_out_gh_d2(gEMLSimLogRunIdx, :) = out_gh_d2.';
elseif(isrow(out_gh_d2))
	gEMLSimLogVal_out_gh_d2(gEMLSimLogRunIdx, :) = out_gh_d2;
else
	gEMLSimLogVal_out_gh_d2(gEMLSimLogRunIdx, :) = {out_gh_d2};
end

if isstruct(out_gv_d2)
	gEMLSimLogVal_out_gv_d2(gEMLSimLogRunIdx, :) = out_gv_d2;
elseif isscalar(out_gv_d2)
	gEMLSimLogVal_out_gv_d2(gEMLSimLogRunIdx, :) = out_gv_d2;
elseif iscolumn(out_gv_d2)
	gEMLSimLogVal_out_gv_d2(gEMLSimLogRunIdx, :) = out_gv_d2.';
elseif(isrow(out_gv_d2))
	gEMLSimLogVal_out_gv_d2(gEMLSimLogRunIdx, :) = out_gv_d2;
else
	gEMLSimLogVal_out_gv_d2(gEMLSimLogRunIdx, :) = {out_gv_d2};
end

gEMLSimLogRunIdx = gEMLSimLogRunIdx+1;

