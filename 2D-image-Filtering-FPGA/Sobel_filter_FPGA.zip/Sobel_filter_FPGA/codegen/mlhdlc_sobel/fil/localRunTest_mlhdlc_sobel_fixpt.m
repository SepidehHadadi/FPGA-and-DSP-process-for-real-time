function localRunTest_mlhdlc_sobel_fixpt
   fxptPath = 'C:\Users\MAM\Desktop\2D_Filtering_FPGA\Sobel_filter_FPGA\codegen\mlhdlc_sobel\fixpt';
addpath(fxptPath);
cleanupObj = onCleanup(@() rmpath(fxptPath));

   mlhdlc_sobel_tb_fil;
end

