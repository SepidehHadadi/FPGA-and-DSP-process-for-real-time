#include "__cf_fil_videosharp_sim.h"
#ifndef RTW_HEADER_fil_videosharp_sim_h_
#define RTW_HEADER_fil_videosharp_sim_h_
#include <stddef.h>
#include <string.h>
#include "rtw_modelmap.h"
#ifndef fil_videosharp_sim_COMMON_INCLUDES_
#define fil_videosharp_sim_COMMON_INCLUDES_
#include <stdlib.h>
#include "rtwtypes.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "sigstream_rtw.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "raccel.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "rt_logging.h"
#include "dt_info.h"
#include "ext_work.h"
#include "filcommon_capi.hpp"
#include "stdlib.h"
#include "stdio.h"
#include "HostLib_MMFile.h"
#include "HostLib_Multimedia.h"
#endif
#include "fil_videosharp_sim_types.h"
#include "multiword_types.h"
#include "rtGetNaN.h"
#include "rt_nonfinite.h"
#include "mwmathutil.h"
#include "rt_defines.h"
#include "rtGetInf.h"
#define MODEL_NAME fil_videosharp_sim
#define NSAMPLE_TIMES (2) 
#define NINPUTS (0)       
#define NOUTPUTS (0)     
#define NBLOCKIO (37) 
#define NUM_ZC_EVENTS (3) 
#ifndef NCSTATES
#define NCSTATES (0)   
#elif NCSTATES != 0
#error Invalid specification of NCSTATES defined in compiler command
#endif
#ifndef rtmGetDataMapInfo
#define rtmGetDataMapInfo(rtm) (*rt_dataMapInfoPtr)
#endif
#ifndef rtmSetDataMapInfo
#define rtmSetDataMapInfo(rtm, val) (rt_dataMapInfoPtr = &val)
#endif
#ifndef IN_RACCEL_MAIN
#endif
typedef struct { uint8_T c4qjhbvh3g [ 42240 ] ; } bscnerhrsu ; typedef struct
{ uint8_T cpoh2looqz [ 42240 ] ; } esso3nnkbp ; typedef struct { int32_T
bolnweqpxw ; uint8_T akoskppbih [ 42240 ] ; int8_T nzofjgicqg ; } p4nh3oqlhy
; typedef struct { uint8_T ljwteyu2qv [ 42240 ] ; } lmeozif4if ; typedef
struct { int8_T lfya5jsxdb ; } is0rrl3t2m ; typedef struct { ZCSigState
cclksiqhzv ; } c5fs3jeygs ; typedef struct { uint8_T o5wnfdweb1 [ 42240 ] ;
uint8_T ph2ms1w2gh ; uint8_T e3or5hi53b [ 42240 ] ; uint8_T klxyj2wepv ;
uint8_T pkisk4c5w5 [ 42240 ] ; uint8_T grqrubiaoy ; uint8_T i1hm2nlh3k ;
uint8_T ihuqv4edg3 ; uint8_T pn3popodna ; uint8_T jf2vo3oy2f [ 42240 ] ;
uint8_T ibjdq010lc [ 42240 ] ; uint8_T fnt5vk5v3b [ 42240 ] ; uint8_T
jb4bvh2jg0 [ 42240 ] ; uint8_T hpum20ybfk [ 42240 ] ; uint8_T ei330voctg [
42240 ] ; uint8_T oidhnxlzrn [ 42240 ] ; uint8_T ag2yqwewan [ 42240 ] ;
uint8_T autpxnj4rh [ 42240 ] ; uint8_T iqyh2bdr3j [ 42240 ] ; uint8_T
g3tjfoemzo [ 42240 ] ; uint8_T cedr240vrj [ 42240 ] ; uint8_T bo4f3pqa3k [
21120 ] ; uint8_T jpemu0m5jb [ 21120 ] ; boolean_T mqkcirpnav ; boolean_T
ajmukknkba ; uint8_T bjwgh3zhq3 ; uint8_T k3o5ecaomc ; uint8_T ndclinny1v ;
lmeozif4if d1lln4iu3m ; lmeozif4if bosgivqpz4 ; lmeozif4if ildclrdm44a ;
esso3nnkbp nwx4oddprh ; esso3nnkbp exx2sgg2c1 ; esso3nnkbp mc0ac3mqpt3 ;
bscnerhrsu dehuj5bzxu ; bscnerhrsu g3co00rhsr ; bscnerhrsu ia4sifx1pp ; } B ;
typedef struct { real_T cfvviahwgs ; real_T nf53pai11t ; real_T btv0brqgud ;
real_T gy3colbg2d [ 137 ] ; real_T nuoi2bpcqb [ 5 ] ; real_T kobal3a2ry [ 11
] ; real_T kixhks45oc ; real_T p3f52jnckb ; real_T msngf5zymf ; struct { void
* filcommon_PortInfo_Inputs ; void * filcommon_PortInfo_Outputs ; void *
filcommon_BlockInfoT ; void * filcommon_SoftwareVersion ; void *
filcommon_Error_StatusAndMsg ; } ewug0yyuyo ; int32_T l0wyyt10jc ; int32_T
k0hbnlu5x1 ; int32_T ktnony3hbz ; uint32_T afib14q5zg ; uint8_T htr0gxofmj [
42240 ] ; uint8_T i3atoxqjmk [ 42240 ] ; uint8_T fvq1rooxjr [ 42240 ] ;
uint8_T ovazadzx53 [ 42240 ] ; uint8_T ar2gdpszka [ 42240 ] ; uint8_T
b5fsf4ugkz [ 42240 ] ; volatile int8_T bsztjvk1v2 ; volatile uint8_T
nzbtkt4pjn [ 84480 ] ; uint8_T blvplwahnx [ 42240 ] ; uint8_T dt1wcwu32n [
21120 ] ; uint8_T fstvboqg4t [ 42240 ] ; boolean_T arufmtcy3m ; is0rrl3t2m
d1lln4iu3m ; is0rrl3t2m bosgivqpz4 ; is0rrl3t2m ildclrdm44a ; p4nh3oqlhy
nwx4oddprh ; p4nh3oqlhy exx2sgg2c1 ; p4nh3oqlhy mc0ac3mqpt3 ; } DW ; typedef
struct { c5fs3jeygs d1lln4iu3m ; c5fs3jeygs bosgivqpz4 ; c5fs3jeygs
ildclrdm44a ; } PrevZCX ; typedef struct { rtwCAPI_ModelMappingInfo mmi ; }
DataMapInfo ; struct P_ { uint8_T BalanceLatencies_DelayLength ; uint8_T
BalanceLatencies_InitialCondition ; uint8_T Unbuffer_ic ; uint8_T
RateTransition2_X0 ; uint8_T BalanceLatencies_DelayLength_iqg5kwcyls ;
uint8_T BalanceLatencies_InitialCondition_by3kggjded ; uint8_T Unbuffer1_ic ;
uint8_T BalanceLatencies_DelayLength_nzwuirigpx ; uint8_T
BalanceLatencies_InitialCondition_gdswlhk2br ; uint8_T Unbuffer2_ic ; uint8_T
Gain_Gain [ 5 ] ; } ; extern const char * RT_MEMORY_ALLOCATION_ERROR ; extern
B rtB ; extern DW rtDW ; extern PrevZCX rtPrevZCX ; extern P rtP ; extern
const rtwCAPI_ModelMappingStaticInfo * fil_videosharp_sim_GetCAPIStaticMap (
void ) ; extern SimStruct * const rtS ; extern const int_T gblNumToFiles ;
extern const int_T gblNumFrFiles ; extern const int_T gblNumFrWksBlocks ;
extern rtInportTUtable * gblInportTUtables ; extern const char *
gblInportFileName ; extern const int_T gblNumRootInportBlks ; extern const
int_T gblNumModelInputs ; extern const int_T gblInportDataTypeIdx [ ] ;
extern const int_T gblInportDims [ ] ; extern const int_T gblInportComplex [
] ; extern const int_T gblInportInterpoFlag [ ] ; extern const int_T
gblInportContinuous [ ] ; extern const int_T gblParameterTuningTid ; extern
size_t gblCurrentSFcnIdx ; extern size_t * gblChildIdxToInfoIdx ; extern
DataMapInfo * rt_dataMapInfoPtr ; extern rtwCAPI_ModelMappingInfo *
rt_modelMapInfoPtr ; void MdlOutputs ( int_T tid ) ; void
MdlOutputsParameterSampleTime ( int_T tid ) ; void MdlUpdate ( int_T tid ) ;
void MdlTerminate ( void ) ; void MdlInitializeSizes ( void ) ; void
MdlInitializeSampleTimes ( void ) ; SimStruct * raccel_register_model ( void
) ;
#endif
