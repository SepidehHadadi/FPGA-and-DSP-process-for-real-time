#include "__cf_fil_videosharp_sim.h"
#include "rt_logging_mmi.h"
#include "fil_videosharp_sim_capi.h"
#include <math.h>
#include "fil_videosharp_sim.h"
#include "fil_videosharp_sim_private.h"
#include "fil_videosharp_sim_dt.h"
extern void * CreateDiagnosticAsVoidPtr_wrapper ( const char * id , int nargs
, ... ) ; RTWExtModeInfo * gblRTWExtModeInfo = NULL ; extern boolean_T
gblExtModeStartPktReceived ; void raccelForceExtModeShutdown ( ) { if ( !
gblExtModeStartPktReceived ) { boolean_T stopRequested = false ;
rtExtModeWaitForStartPkt ( gblRTWExtModeInfo , 2 , & stopRequested ) ; }
rtExtModeShutdown ( 2 ) ; } const int_T gblNumToFiles = 0 ; const int_T
gblNumFrFiles = 0 ; const int_T gblNumFrWksBlocks = 0 ;
#ifdef RSIM_WITH_SOLVER_MULTITASKING
boolean_T gbl_raccel_isMultitasking = 1 ;
#else
boolean_T gbl_raccel_isMultitasking = 0 ;
#endif
boolean_T gbl_raccel_tid01eq = 0 ; int_T gbl_raccel_NumST = 2 ; const char_T
* gbl_raccel_Version = "8.12 (R2017a) 16-Feb-2017" ; void
raccel_setup_MMIStateLog ( SimStruct * S ) {
#ifdef UseMMIDataLogging
rt_FillStateSigInfoFromMMI ( ssGetRTWLogInfo ( S ) , & ssGetErrorStatus ( S )
) ;
#else
UNUSED_PARAMETER ( S ) ;
#endif
} static DataMapInfo rt_dataMapInfo ; DataMapInfo * rt_dataMapInfoPtr = &
rt_dataMapInfo ; rtwCAPI_ModelMappingInfo * rt_modelMapInfoPtr = & (
rt_dataMapInfo . mmi ) ; const char * gblSlvrJacPatternFileName =
"slprj\\raccel\\fil_videosharp_sim\\fil_videosharp_sim_Jpattern.mat" ; const
int_T gblNumRootInportBlks = 0 ; const int_T gblNumModelInputs = 0 ; extern
rtInportTUtable * gblInportTUtables ; extern const char * gblInportFileName ;
const int_T gblInportDataTypeIdx [ ] = { - 1 } ; const int_T gblInportDims [
] = { - 1 } ; const int_T gblInportComplex [ ] = { - 1 } ; const int_T
gblInportInterpoFlag [ ] = { - 1 } ; const int_T gblInportContinuous [ ] = {
- 1 } ;
#include "simstruc.h"
#include "fixedpoint.h"
#define ftswd1hl50 (0.0)
B rtB ; DW rtDW ; PrevZCX rtPrevZCX ; static SimStruct model_S ; SimStruct *
const rtS = & model_S ; static real_T nj2netd2ho ( real_T x ) ; void
aghbwax5ws ( const uint8_T kk2fbcuwvb [ 42240 ] , bscnerhrsu * localB ) {
int32_T i ; int32_T i_p ; for ( i_p = 0 ; i_p < 176 ; i_p ++ ) { for ( i = 0
; i < 240 ; i ++ ) { localB -> c4qjhbvh3g [ i + 240 * i_p ] = kk2fbcuwvb [
176 * i + i_p ] ; } } } void gklr2pga5p ( p4nh3oqlhy * localDW ) { int32_T
idxIn ; int32_T i ; localDW -> akoskppbih [ 0 ] = ( ( uint8_T ) 0U ) ; idxIn
= 1 ; for ( i = 0 ; i < 42239 ; i ++ ) { localDW -> akoskppbih [ idxIn ] = (
( uint8_T ) 0U ) ; idxIn ++ ; } localDW -> bolnweqpxw = 0 ; } void mc0ac3mqpt
( boolean_T br5npshbar , esso3nnkbp * localB , p4nh3oqlhy * localDW ) {
int32_T idx2 ; int32_T k ; if ( br5npshbar ) { for ( k = 0 ; k < 42240 -
localDW -> bolnweqpxw ; k ++ ) { localB -> cpoh2looqz [ k ] = localDW ->
akoskppbih [ localDW -> bolnweqpxw + k ] ; } idx2 = 42240 - localDW ->
bolnweqpxw ; for ( k = 0 ; k < localDW -> bolnweqpxw ; k ++ ) { localB ->
cpoh2looqz [ idx2 + k ] = localDW -> akoskppbih [ k ] ; } srUpdateBC (
localDW -> nzofjgicqg ) ; } } void aqonbsnzoq ( boolean_T br5npshbar ,
uint8_T kli4jik0kv , p4nh3oqlhy * localDW ) { if ( br5npshbar ) { localDW ->
akoskppbih [ localDW -> bolnweqpxw ] = kli4jik0kv ; localDW -> bolnweqpxw ++
; while ( localDW -> bolnweqpxw >= 42240 ) { localDW -> bolnweqpxw -= 42240 ;
} } } void ildclrdm44 ( boolean_T ds5nr5um4u , const uint8_T dkiqhsuu2g [
42240 ] , lmeozif4if * localB , is0rrl3t2m * localDW , c5fs3jeygs * localZCE
) { int32_T yElIdx ; int32_T uElOffset1 ; int32_T ntIdx1 ; int32_T uElOffset0
; int32_T ntIdx0 ; if ( ds5nr5um4u && ( localZCE -> cclksiqhzv != POS_ZCSIG )
) { yElIdx = 0 ; uElOffset1 = 0 ; for ( ntIdx1 = 0 ; ntIdx1 < 240 ; ntIdx1 ++
) { uElOffset0 = uElOffset1 ; for ( ntIdx0 = 0 ; ntIdx0 < 176 ; ntIdx0 ++ ) {
localB -> ljwteyu2qv [ yElIdx ] = dkiqhsuu2g [ uElOffset0 ] ; yElIdx ++ ;
uElOffset0 += 240 ; } uElOffset1 ++ ; } localDW -> lfya5jsxdb = 4 ; }
localZCE -> cclksiqhzv = ds5nr5um4u ; } static real_T nj2netd2ho ( real_T x )
{ real_T r ; if ( ( ! muDoubleScalarIsInf ( x ) ) && ( ! muDoubleScalarIsNaN
( x ) ) ) { if ( x == 0.0 ) { r = 0.0 ; } else { r = muDoubleScalarRem ( x ,
240.0 ) ; if ( r == 0.0 ) { r = 0.0 ; } else { if ( x < 0.0 ) { r += 240.0 ;
} } } } else { r = ( rtNaN ) ; } return r ; } void MdlInitialize ( void ) {
int32_T i ; rtDW . l0wyyt10jc = 0 ; rtDW . k0hbnlu5x1 = 0 ; rtDW . ktnony3hbz
= 0 ; for ( i = 0 ; i < 42240 ; i ++ ) { rtDW . htr0gxofmj [ i ] = rtP .
BalanceLatencies_InitialCondition ; rtDW . i3atoxqjmk [ i ] = rtP .
Unbuffer_ic ; rtDW . nzbtkt4pjn [ i ] = rtP . RateTransition2_X0 ; rtDW .
fvq1rooxjr [ i ] = rtP . BalanceLatencies_InitialCondition_by3kggjded ; rtDW
. ovazadzx53 [ i ] = rtP . Unbuffer1_ic ; rtDW . ar2gdpszka [ i ] = rtP .
BalanceLatencies_InitialCondition_gdswlhk2br ; rtDW . b5fsf4ugkz [ i ] = rtP
. Unbuffer2_ic ; } LibReset ( & rtDW . gy3colbg2d [ 0U ] ) ; rtDW .
kixhks45oc = 0.0 ; rtDW . p3f52jnckb = 1.0 ; rtDW . msngf5zymf = 0.0 ; rtDW .
arufmtcy3m = false ; gklr2pga5p ( & rtDW . mc0ac3mqpt3 ) ; gklr2pga5p ( &
rtDW . exx2sgg2c1 ) ; gklr2pga5p ( & rtDW . nwx4oddprh ) ; } void MdlStart (
void ) { char_T * sErr ; { void * * slioCatalogueAddr = rt_slioCatalogueAddr
( ) ; void * r2 = ( NULL ) ; void * * pOSigstreamManagerAddr = ( NULL ) ;
const char * errorCreatingOSigstreamManager = ( NULL ) ; const char *
errorAddingR2SharedResource = ( NULL ) ; * slioCatalogueAddr =
rtwGetNewSlioCatalogue ( rt_GetMatSigLogSelectorFileName ( ) ) ;
errorAddingR2SharedResource = rtwAddR2SharedResource (
rtwGetPointerFromUniquePtr ( rt_slioCatalogue ( ) ) , 1 ) ; if (
errorAddingR2SharedResource != ( NULL ) ) { rtwTerminateSlioCatalogue (
slioCatalogueAddr ) ; * slioCatalogueAddr = ( NULL ) ; ssSetErrorStatus ( rtS
, errorAddingR2SharedResource ) ; return ; } r2 = rtwGetR2SharedResource (
rtwGetPointerFromUniquePtr ( rt_slioCatalogue ( ) ) ) ;
pOSigstreamManagerAddr = rt_GetOSigstreamManagerAddr ( ) ;
errorCreatingOSigstreamManager = rtwOSigstreamManagerCreateInstance (
rt_GetMatSigLogSelectorFileName ( ) , r2 , pOSigstreamManagerAddr ) ; if (
errorCreatingOSigstreamManager != ( NULL ) ) { * pOSigstreamManagerAddr = (
NULL ) ; ssSetErrorStatus ( rtS , errorCreatingOSigstreamManager ) ; return ;
} } { struct filcommon_PortInfoT * InputPortInfoArray ; struct
filcommon_PortInfoT * OutputPortInfoArray ; struct filcommon_BlockInfoT *
BlockInfo_V ; struct filcommon_SoftwareVersionT * SoftwareVersion_V ; struct
filcommon_Error_StatusAndMsg * Error_StatusAndMsg ; static char_T ErrorMsg [
FIL_CAPI_MAX_ERROR_STR ] = "" ; char connection [ ] = "UDP" ; char libName [
] = "libmwrtiostreamtcpip" ; char libParams [ ] =
 "-protocol UDP -port 50101 -hostname 192.168.0.2 -client 1 -recv_timeout_secs 1 -blocking 1"
; char protoParams [ ] = "" ; InputPortInfoArray = ( struct
filcommon_PortInfoT * ) malloc ( sizeof ( struct filcommon_PortInfoT ) * 4 )
; OutputPortInfoArray = ( struct filcommon_PortInfoT * ) malloc ( sizeof (
struct filcommon_PortInfoT ) * 5 ) ; BlockInfo_V = ( struct
filcommon_BlockInfoT * ) malloc ( sizeof ( struct filcommon_BlockInfoT ) ) ;
SoftwareVersion_V = ( struct filcommon_SoftwareVersionT * ) malloc ( sizeof (
struct filcommon_SoftwareVersionT ) ) ; Error_StatusAndMsg = ( struct
filcommon_Error_StatusAndMsg * ) malloc ( sizeof ( struct
filcommon_Error_StatusAndMsg ) ) ; Error_StatusAndMsg -> Status = 0 ;
BlockInfo_V -> numInputPorts = 4 ; BlockInfo_V -> inputDataSetBitwidth = 29 ;
BlockInfo_V -> inputDataSetBytewidth = 4 ; BlockInfo_V -> numOutputPorts = 5
; BlockInfo_V -> outputDataSetBitwidth = 30 ; BlockInfo_V ->
outputDataSetBytewidth = 5 ; BlockInfo_V -> processingMode = 0U ; BlockInfo_V
-> inputFrameSize = 1 ; BlockInfo_V -> outputFrameSize = 1 ; BlockInfo_V ->
overclocking . inhRule = 4294967273U ; BlockInfo_V -> overclocking . value =
1U ; BlockInfo_V -> blkBaseFrameTime = 9.8642676767676768E-7 ; BlockInfo_V ->
blkBaseScalarTime = 9.8642676767676768E-7 ; BlockInfo_V -> mdlSTime_frameSize
= 1.0 ; BlockInfo_V -> mdlSTime_scalarAsDbl = 9.8642676767676768E-7 ;
BlockInfo_V -> inputSTime_frameSize = 1.0 ; BlockInfo_V ->
inputSTime_scalarAsDbl = 9.8642676767676768E-7 ; BlockInfo_V ->
outputSTime_frameSize = 1.0 ; BlockInfo_V -> outputSTime_scalarAsDbl =
9.8642676767676768E-7 ; SoftwareVersion_V -> majorRev = 2U ;
SoftwareVersion_V -> minorRev = 0U ; InputPortInfoArray [ 0 ] . name = malloc
( sizeof ( "syncin" ) ) ; sprintf ( InputPortInfoArray [ 0 ] . name ,
"syncin" ) ; InputPortInfoArray [ 0 ] . signedness = 0U ; InputPortInfoArray
[ 0 ] . elemBitwidth = 5U ; InputPortInfoArray [ 0 ] . validPhase = 0 ;
InputPortInfoArray [ 0 ] . numElems = 1U ; InputPortInfoArray [ 0 ] .
elemSize = 1U ; InputPortInfoArray [ 0 ] . buf = & rtB . bjwgh3zhq3 ;
InputPortInfoArray [ 0 ] . portSTime_frameSize = 1.0 ; InputPortInfoArray [ 0
] . portSTime_scalarAsDbl = 9.8642676767676768E-7 ; InputPortInfoArray [ 1 ]
. name = malloc ( sizeof ( "yin" ) ) ; sprintf ( InputPortInfoArray [ 1 ] .
name , "yin" ) ; InputPortInfoArray [ 1 ] . signedness = 0U ;
InputPortInfoArray [ 1 ] . elemBitwidth = 8U ; InputPortInfoArray [ 1 ] .
validPhase = 0 ; InputPortInfoArray [ 1 ] . numElems = 1U ;
InputPortInfoArray [ 1 ] . elemSize = 1U ; InputPortInfoArray [ 1 ] . buf = &
rtB . ph2ms1w2gh ; InputPortInfoArray [ 1 ] . portSTime_frameSize = 1.0 ;
InputPortInfoArray [ 1 ] . portSTime_scalarAsDbl = 9.8642676767676768E-7 ;
InputPortInfoArray [ 2 ] . name = malloc ( sizeof ( "cbin" ) ) ; sprintf (
InputPortInfoArray [ 2 ] . name , "cbin" ) ; InputPortInfoArray [ 2 ] .
signedness = 0U ; InputPortInfoArray [ 2 ] . elemBitwidth = 8U ;
InputPortInfoArray [ 2 ] . validPhase = 0 ; InputPortInfoArray [ 2 ] .
numElems = 1U ; InputPortInfoArray [ 2 ] . elemSize = 1U ; InputPortInfoArray
[ 2 ] . buf = & rtB . klxyj2wepv ; InputPortInfoArray [ 2 ] .
portSTime_frameSize = 1.0 ; InputPortInfoArray [ 2 ] . portSTime_scalarAsDbl
= 9.8642676767676768E-7 ; InputPortInfoArray [ 3 ] . name = malloc ( sizeof (
"crin" ) ) ; sprintf ( InputPortInfoArray [ 3 ] . name , "crin" ) ;
InputPortInfoArray [ 3 ] . signedness = 0U ; InputPortInfoArray [ 3 ] .
elemBitwidth = 8U ; InputPortInfoArray [ 3 ] . validPhase = 0 ;
InputPortInfoArray [ 3 ] . numElems = 1U ; InputPortInfoArray [ 3 ] .
elemSize = 1U ; InputPortInfoArray [ 3 ] . buf = & rtB . grqrubiaoy ;
InputPortInfoArray [ 3 ] . portSTime_frameSize = 1.0 ; InputPortInfoArray [ 3
] . portSTime_scalarAsDbl = 9.8642676767676768E-7 ; OutputPortInfoArray [ 0 ]
. name = malloc ( sizeof ( "ce_out" ) ) ; sprintf ( OutputPortInfoArray [ 0 ]
. name , "ce_out" ) ; OutputPortInfoArray [ 0 ] . signedness = 0U ;
OutputPortInfoArray [ 0 ] . elemBitwidth = 1U ; OutputPortInfoArray [ 0 ] .
validPhase = 0 ; OutputPortInfoArray [ 0 ] . numElems = 1U ;
OutputPortInfoArray [ 0 ] . elemSize = 1U ; OutputPortInfoArray [ 0 ] . buf =
& rtB . ndclinny1v ; OutputPortInfoArray [ 0 ] . portSTime_frameSize = 1.0 ;
OutputPortInfoArray [ 0 ] . portSTime_scalarAsDbl = 9.8642676767676768E-7 ;
OutputPortInfoArray [ 1 ] . name = malloc ( sizeof ( "syncout" ) ) ; sprintf
( OutputPortInfoArray [ 1 ] . name , "syncout" ) ; OutputPortInfoArray [ 1 ]
. signedness = 0U ; OutputPortInfoArray [ 1 ] . elemBitwidth = 5U ;
OutputPortInfoArray [ 1 ] . validPhase = 0 ; OutputPortInfoArray [ 1 ] .
numElems = 1U ; OutputPortInfoArray [ 1 ] . elemSize = 1U ;
OutputPortInfoArray [ 1 ] . buf = & rtB . k3o5ecaomc ; OutputPortInfoArray [
1 ] . portSTime_frameSize = 1.0 ; OutputPortInfoArray [ 1 ] .
portSTime_scalarAsDbl = 9.8642676767676768E-7 ; OutputPortInfoArray [ 2 ] .
name = malloc ( sizeof ( "yout" ) ) ; sprintf ( OutputPortInfoArray [ 2 ] .
name , "yout" ) ; OutputPortInfoArray [ 2 ] . signedness = 0U ;
OutputPortInfoArray [ 2 ] . elemBitwidth = 8U ; OutputPortInfoArray [ 2 ] .
validPhase = 0 ; OutputPortInfoArray [ 2 ] . numElems = 1U ;
OutputPortInfoArray [ 2 ] . elemSize = 1U ; OutputPortInfoArray [ 2 ] . buf =
& rtB . i1hm2nlh3k ; OutputPortInfoArray [ 2 ] . portSTime_frameSize = 1.0 ;
OutputPortInfoArray [ 2 ] . portSTime_scalarAsDbl = 9.8642676767676768E-7 ;
OutputPortInfoArray [ 3 ] . name = malloc ( sizeof ( "cbout" ) ) ; sprintf (
OutputPortInfoArray [ 3 ] . name , "cbout" ) ; OutputPortInfoArray [ 3 ] .
signedness = 0U ; OutputPortInfoArray [ 3 ] . elemBitwidth = 8U ;
OutputPortInfoArray [ 3 ] . validPhase = 0 ; OutputPortInfoArray [ 3 ] .
numElems = 1U ; OutputPortInfoArray [ 3 ] . elemSize = 1U ;
OutputPortInfoArray [ 3 ] . buf = & rtB . ihuqv4edg3 ; OutputPortInfoArray [
3 ] . portSTime_frameSize = 1.0 ; OutputPortInfoArray [ 3 ] .
portSTime_scalarAsDbl = 9.8642676767676768E-7 ; OutputPortInfoArray [ 4 ] .
name = malloc ( sizeof ( "crout" ) ) ; sprintf ( OutputPortInfoArray [ 4 ] .
name , "crout" ) ; OutputPortInfoArray [ 4 ] . signedness = 0U ;
OutputPortInfoArray [ 4 ] . elemBitwidth = 8U ; OutputPortInfoArray [ 4 ] .
validPhase = 0 ; OutputPortInfoArray [ 4 ] . numElems = 1U ;
OutputPortInfoArray [ 4 ] . elemSize = 1U ; OutputPortInfoArray [ 4 ] . buf =
& rtB . pn3popodna ; OutputPortInfoArray [ 4 ] . portSTime_frameSize = 1.0 ;
OutputPortInfoArray [ 4 ] . portSTime_scalarAsDbl = 9.8642676767676768E-7 ;
rtDW . ewug0yyuyo . filcommon_PortInfo_Inputs = InputPortInfoArray ; rtDW .
ewug0yyuyo . filcommon_PortInfo_Outputs = OutputPortInfoArray ; rtDW .
ewug0yyuyo . filcommon_BlockInfoT = BlockInfo_V ; rtDW . ewug0yyuyo .
filcommon_SoftwareVersion = SoftwareVersion_V ; rtDW . ewug0yyuyo .
filcommon_Error_StatusAndMsg = Error_StatusAndMsg ; filcommon_create ( & rtDW
. afib14q5zg , Error_StatusAndMsg ) ; filcommon_initializeAndStart ( rtDW .
afib14q5zg , 4 , InputPortInfoArray , 5 , OutputPortInfoArray , BlockInfo_V ,
connection , libName , libParams , protoParams , 1 , 1 , SoftwareVersion_V ,
0 , Error_StatusAndMsg ) ; if ( Error_StatusAndMsg -> Status ) { strcpy (
ErrorMsg , Error_StatusAndMsg -> ErrorMsg ) ; ssSetErrorStatus ( rtS ,
ErrorMsg ) ; return ; } } sErr = GetErrorBuffer ( & rtDW . gy3colbg2d [ 0U ]
) ; CreateHostLibrary ( "frommmfile.dll" , & rtDW . gy3colbg2d [ 0U ] ) ;
createAudioInfo ( & rtDW . nuoi2bpcqb [ 0U ] , 0U , 0U , 0.0 , 0 , 0 , 0 , 0
, 0 ) ; createVideoInfo ( & rtDW . kobal3a2ry [ 0U ] , 1U , 24.0 ,
24.000038400061442 , "RGB " , 3 , 3 , 240 , 176 , 0U , 3 , 1 , 0 ) ; if ( *
sErr == 0 ) { LibCreate_FromMMFile ( & rtDW . gy3colbg2d [ 0U ] , 0 , ( void
* )
 "C:\\Program Files\\MATLAB\\R2017a\\toolbox\\shared\\eda\\fil\\fildemos\\fil_cat.avi"
, 1 , "" , "" , & rtDW . nuoi2bpcqb [ 0U ] , & rtDW . kobal3a2ry [ 0U ] , 0U
, 1U , 3U , 0U , 0U , 1U ) ; } if ( * sErr == 0 ) { LibStart ( & rtDW .
gy3colbg2d [ 0U ] ) ; } if ( * sErr != 0 ) { DestroyHostLibrary ( & rtDW .
gy3colbg2d [ 0U ] ) ; if ( * sErr != 0 ) { ssSetErrorStatus ( rtS , sErr ) ;
ssSetStopRequested ( rtS , 1 ) ; } } MdlInitialize ( ) ; { bool
externalInputIsInDatasetFormat = false ; void * pISigstreamManager =
rt_GetISigstreamManager ( ) ; rtwISigstreamManagerGetInputIsInDatasetFormat (
pISigstreamManager , & externalInputIsInDatasetFormat ) ; if (
externalInputIsInDatasetFormat ) { } } } void MdlOutputs ( int_T tid ) {
boolean_T agmbfcn3fg ; boolean_T hbx5k5xnzy ; uint8_T pweqdjheip ; uint8_T
k2rmb2ca4e ; uint8_T eit5bwv1wk ; uint8_T k24z1ei4ie ; uint8_T ea4hitojkb ;
uint8_T ontveiyunp ; uint8_T mh2p4ro4zj ; uint8_T etkbkcm3hb ; uint8_T
ohgc2l5qa2 ; uint8_T gbzgkdr14e ; uint32_T rConst ; uint32_T gConst ;
uint32_T bConst ; char_T * sErr ; void * source_R ; void * source_G ; void *
source_B ; uint32_T cc1 ; uint32_T pos ; uint32_T neg ; uint32_T yDiff ;
real_T modOfWidth ; boolean_T lineStart ; boolean_T lineEnd ; boolean_T
frameStart ; boolean_T frameEnd ; boolean_T isActivePixel ; boolean_T
go5dgh5izu [ 5 ] ; int32_T q ; int32_T p ; int32_T m ; int32_T outStep ;
int32_T n ; uint8_T tmp ; int32_T i ; int32_T tmp_p ; srClearBC ( rtDW .
mc0ac3mqpt3 . nzofjgicqg ) ; srClearBC ( rtDW . ildclrdm44a . lfya5jsxdb ) ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { for ( i = 0 ; i < 42240 ; i ++ ) { rtB
. o5wnfdweb1 [ i ] = rtDW . htr0gxofmj [ i ] ; rtDW . i3atoxqjmk [ i ] = rtB
. o5wnfdweb1 [ i ] ; } rtDW . l0wyyt10jc = 0 ; } rtB . ph2ms1w2gh = rtDW .
i3atoxqjmk [ rtDW . l0wyyt10jc ] ; if ( rtDW . l0wyyt10jc < 42239 ) { rtDW .
l0wyyt10jc ++ ; } if ( rtDW . msngf5zymf < 42240.0 ) { rtDW . msngf5zymf ++ ;
for ( i = 0 ; i < 5 ; i ++ ) { go5dgh5izu [ i ] = false ; } } else {
modOfWidth = nj2netd2ho ( rtDW . p3f52jnckb ) ; isActivePixel = ( ( (
modOfWidth > ftswd1hl50 ) || ( ! ( modOfWidth != 0.0 ) ) ) && ( rtDW .
p3f52jnckb <= 42240.0 ) ) ; if ( isActivePixel ) { rtDW . kixhks45oc ++ ;
lineStart = ( nj2netd2ho ( rtDW . kixhks45oc ) == 1.0 ) ; lineEnd = ! (
nj2netd2ho ( rtDW . kixhks45oc ) != 0.0 ) ; frameStart = ( rtDW . kixhks45oc
== 1.0 ) ; frameEnd = ( rtDW . kixhks45oc == 42240.0 ) ; } else { lineStart =
false ; lineEnd = false ; frameStart = false ; frameEnd = false ; } rtDW .
p3f52jnckb ++ ; if ( rtDW . p3f52jnckb == 42241.0 ) { rtDW . p3f52jnckb = 1.0
; } if ( frameEnd ) { rtDW . kixhks45oc = 0.0 ; } go5dgh5izu [ 0 ] =
isActivePixel ; go5dgh5izu [ 1 ] = lineStart ; go5dgh5izu [ 2 ] = lineEnd ;
go5dgh5izu [ 3 ] = frameStart ; go5dgh5izu [ 4 ] = frameEnd ; } tmp = 0U ;
for ( i = 0 ; i < 5 ; i ++ ) { tmp = ( uint8_T ) ( ( uint32_T ) tmp + (
uint8_T ) ( go5dgh5izu [ i ] ? ( int32_T ) rtP . Gain_Gain [ i ] : 0 ) ) ; }
rtB . bjwgh3zhq3 = ( uint8_T ) ( tmp & 31 ) ; if ( ssIsSampleHit ( rtS , 1 ,
0 ) ) { for ( i = 0 ; i < 42240 ; i ++ ) { rtB . e3or5hi53b [ i ] = rtDW .
fvq1rooxjr [ i ] ; rtDW . ovazadzx53 [ i ] = rtB . e3or5hi53b [ i ] ; } rtDW
. k0hbnlu5x1 = 0 ; } rtB . klxyj2wepv = rtDW . ovazadzx53 [ rtDW . k0hbnlu5x1
] ; if ( rtDW . k0hbnlu5x1 < 42239 ) { rtDW . k0hbnlu5x1 ++ ; } if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { for ( i = 0 ; i < 42240 ; i ++ ) { rtB .
pkisk4c5w5 [ i ] = rtDW . ar2gdpszka [ i ] ; rtDW . b5fsf4ugkz [ i ] = rtB .
pkisk4c5w5 [ i ] ; } rtDW . ktnony3hbz = 0 ; } rtB . grqrubiaoy = rtDW .
b5fsf4ugkz [ rtDW . ktnony3hbz ] ; if ( rtDW . ktnony3hbz < 42239 ) { rtDW .
ktnony3hbz ++ ; } { struct filcommon_Error_StatusAndMsg * Error_StatusAndMsg
; static char_T ErrorMsg [ FIL_CAPI_MAX_ERROR_STR ] = "" ; uint8_T
IsInputHitArray [ 4 ] ; uint8_T IsOutputHitArray [ 5 ] ; uint32_T ClassID = (
uint32_T ) rtDW . afib14q5zg ; real_T slTime = ssGetTaskTime ( rtS , 0 ) ;
IsInputHitArray [ 0 ] = 1 ; IsInputHitArray [ 1 ] = 1 ; IsInputHitArray [ 2 ]
= 1 ; IsInputHitArray [ 3 ] = 1 ; IsOutputHitArray [ 0 ] = 1 ;
IsOutputHitArray [ 1 ] = 1 ; IsOutputHitArray [ 2 ] = 1 ; IsOutputHitArray [
3 ] = 1 ; IsOutputHitArray [ 4 ] = 1 ; Error_StatusAndMsg = ( struct
filcommon_Error_StatusAndMsg * ) rtDW . ewug0yyuyo .
filcommon_Error_StatusAndMsg ; Error_StatusAndMsg -> Status = 0 ;
filcommon_outputs ( ClassID , 4 , IsInputHitArray , 5 , IsOutputHitArray ,
slTime , 0 , Error_StatusAndMsg ) ; if ( Error_StatusAndMsg -> Status ) {
strcpy ( ErrorMsg , Error_StatusAndMsg -> ErrorMsg ) ; ssSetErrorStatus ( rtS
, ErrorMsg ) ; return ; } } pweqdjheip = ( uint8_T ) ( rtB . k3o5ecaomc & 1 )
; k2rmb2ca4e = pweqdjheip ; etkbkcm3hb = ( uint8_T ) ( ( int32_T ) ( (
uint32_T ) rtB . k3o5ecaomc >> 3 ) & 1 ) ; eit5bwv1wk = etkbkcm3hb ;
mh2p4ro4zj = ( uint8_T ) ( ( int32_T ) ( ( uint32_T ) rtB . k3o5ecaomc >> 4 )
& 1 ) ; k24z1ei4ie = mh2p4ro4zj ; rtB . ajmukknkba = ( rtDW . arufmtcy3m || (
k2rmb2ca4e != 0 ) ) ; rtB . mqkcirpnav = rtDW . arufmtcy3m ; rtDW .
arufmtcy3m = ( k24z1ei4ie != 0 ) ; mc0ac3mqpt ( rtB . ajmukknkba , & rtB .
mc0ac3mqpt3 , & rtDW . mc0ac3mqpt3 ) ; ildclrdm44 ( rtB . mqkcirpnav , rtB .
mc0ac3mqpt3 . cpoh2looqz , & rtB . ildclrdm44a , & rtDW . ildclrdm44a , &
rtPrevZCX . ildclrdm44a ) ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { memcpy ( &
rtB . jf2vo3oy2f [ 0 ] , & rtB . ildclrdm44a . ljwteyu2qv [ 0 ] , 42240U *
sizeof ( uint8_T ) ) ; } mc0ac3mqpt ( rtB . ajmukknkba , & rtB . exx2sgg2c1 ,
& rtDW . exx2sgg2c1 ) ; ildclrdm44 ( rtB . mqkcirpnav , rtB . exx2sgg2c1 .
cpoh2looqz , & rtB . bosgivqpz4 , & rtDW . bosgivqpz4 , & rtPrevZCX .
bosgivqpz4 ) ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { memcpy ( & rtB .
ibjdq010lc [ 0 ] , & rtB . bosgivqpz4 . ljwteyu2qv [ 0 ] , 42240U * sizeof (
uint8_T ) ) ; } mc0ac3mqpt ( rtB . ajmukknkba , & rtB . nwx4oddprh , & rtDW .
nwx4oddprh ) ; ildclrdm44 ( rtB . mqkcirpnav , rtB . nwx4oddprh . cpoh2looqz
, & rtB . d1lln4iu3m , & rtDW . d1lln4iu3m , & rtPrevZCX . d1lln4iu3m ) ; if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { rConst = ( ( uint16_T ) 26149U ) * 128U ;
gConst = ( ( ( uint16_T ) 6419U ) * 128U + ( ( uint16_T ) 13320U ) * 128U ) +
8192U ; bConst = ( ( uint16_T ) 33050U ) * 128U ; for ( i = 0 ; i < 42240 ; i
++ ) { rtB . fnt5vk5v3b [ i ] = rtB . d1lln4iu3m . ljwteyu2qv [ i ] ; yDiff =
rtB . jf2vo3oy2f [ i ] - 16U ; pos = ( yDiff * ( ( uint16_T ) 19077U ) + (
uint32_T ) rtB . fnt5vk5v3b [ i ] * ( ( uint16_T ) 26149U ) ) + 8192U ; if (
pos > rConst ) { cc1 = pos - rConst ; } else { cc1 = 0U ; } cc1 >>= 14 ; if (
cc1 > 255U ) { cc1 = 255U ; } pos = yDiff * ( ( uint16_T ) 19077U ) + gConst
; neg = ( uint32_T ) rtB . ibjdq010lc [ i ] * ( ( uint16_T ) 6419U ) + (
uint32_T ) rtB . fnt5vk5v3b [ i ] * ( ( uint16_T ) 13320U ) ; if ( pos > neg
) { neg = pos - neg ; } else { neg = 0U ; } neg >>= 14 ; if ( neg > 255U ) {
neg = 255U ; } pos = ( yDiff * ( ( uint16_T ) 19077U ) + ( uint32_T ) rtB .
ibjdq010lc [ i ] * ( ( uint16_T ) 33050U ) ) + 8192U ; if ( pos > bConst ) {
yDiff = pos - bConst ; } else { yDiff = 0U ; } yDiff >>= 14 ; if ( yDiff >
255U ) { yDiff = 255U ; } rtB . jb4bvh2jg0 [ i ] = ( uint8_T ) cc1 ; rtB .
hpum20ybfk [ i ] = ( uint8_T ) neg ; rtB . ei330voctg [ i ] = ( uint8_T )
yDiff ; } sErr = GetErrorBuffer ( & rtDW . gy3colbg2d [ 0U ] ) ; source_R = (
void * ) & rtB . oidhnxlzrn [ 0U ] ; source_G = ( void * ) & rtB . bo4f3pqa3k
[ 0U ] ; source_B = ( void * ) & rtB . jpemu0m5jb [ 0U ] ;
LibOutputs_FromMMFile ( & rtDW . gy3colbg2d [ 0U ] , GetNullPointer ( ) ,
GetNullPointer ( ) , source_R , source_G , source_B ) ; if ( * sErr != 0 ) {
ssSetErrorStatus ( rtS , sErr ) ; ssSetStopRequested ( rtS , 1 ) ; } i = 0 ;
outStep = 0 ; for ( n = 0 ; n < 119 ; n ++ ) { p = outStep ; q = i ; for ( m
= 0 ; m < 176 ; m ++ ) { rtB . ag2yqwewan [ p ] = rtB . bo4f3pqa3k [ q ] ;
tmp_p = rtB . bo4f3pqa3k [ q + 176 ] + rtB . bo4f3pqa3k [ q ] ; rtB .
ag2yqwewan [ p + 176 ] = ( uint8_T ) ( tmp_p >> 1 ) ; p ++ ; q ++ ; } outStep
+= 352 ; i += 176 ; } i = 20944 ; for ( m = 0 ; m < 176 ; m ++ ) { outStep =
41888 + m ; rtB . ag2yqwewan [ outStep ] = rtB . bo4f3pqa3k [ i ] ; outStep
+= 176 ; rtB . ag2yqwewan [ outStep ] = rtB . bo4f3pqa3k [ i ] ; i ++ ; } i =
0 ; outStep = 0 ; for ( n = 0 ; n < 119 ; n ++ ) { p = outStep ; q = i ; for
( m = 0 ; m < 176 ; m ++ ) { rtB . autpxnj4rh [ p ] = rtB . jpemu0m5jb [ q ]
; tmp_p = rtB . jpemu0m5jb [ q + 176 ] + rtB . jpemu0m5jb [ q ] ; rtB .
autpxnj4rh [ p + 176 ] = ( uint8_T ) ( tmp_p >> 1 ) ; p ++ ; q ++ ; } outStep
+= 352 ; i += 176 ; } i = 20944 ; for ( m = 0 ; m < 176 ; m ++ ) { outStep =
41888 + m ; rtB . autpxnj4rh [ outStep ] = rtB . jpemu0m5jb [ i ] ; outStep
+= 176 ; rtB . autpxnj4rh [ outStep ] = rtB . jpemu0m5jb [ i ] ; i ++ ; }
rConst = ( ( uint16_T ) 26149U ) * 128U ; gConst = ( ( ( uint16_T ) 6419U ) *
128U + ( ( uint16_T ) 13320U ) * 128U ) + 8192U ; bConst = ( ( uint16_T )
33050U ) * 128U ; for ( i = 0 ; i < 42240 ; i ++ ) { yDiff = rtB . oidhnxlzrn
[ i ] - 16U ; pos = ( yDiff * ( ( uint16_T ) 19077U ) + ( uint32_T ) rtB .
autpxnj4rh [ i ] * ( ( uint16_T ) 26149U ) ) + 8192U ; if ( pos > rConst ) {
cc1 = pos - rConst ; } else { cc1 = 0U ; } cc1 >>= 14 ; if ( cc1 > 255U ) {
cc1 = 255U ; } pos = yDiff * ( ( uint16_T ) 19077U ) + gConst ; neg = (
uint32_T ) rtB . ag2yqwewan [ i ] * ( ( uint16_T ) 6419U ) + ( uint32_T ) rtB
. autpxnj4rh [ i ] * ( ( uint16_T ) 13320U ) ; if ( pos > neg ) { neg = pos -
neg ; } else { neg = 0U ; } neg >>= 14 ; if ( neg > 255U ) { neg = 255U ; }
pos = ( yDiff * ( ( uint16_T ) 19077U ) + ( uint32_T ) rtB . ag2yqwewan [ i ]
* ( ( uint16_T ) 33050U ) ) + 8192U ; if ( pos > bConst ) { yDiff = pos -
bConst ; } else { yDiff = 0U ; } yDiff >>= 14 ; if ( yDiff > 255U ) { yDiff =
255U ; } rtB . iqyh2bdr3j [ i ] = ( uint8_T ) cc1 ; rtB . g3tjfoemzo [ i ] =
( uint8_T ) neg ; rtB . cedr240vrj [ i ] = ( uint8_T ) yDiff ; } aghbwax5ws (
rtB . oidhnxlzrn , & rtB . ia4sifx1pp ) ; aghbwax5ws ( rtB . ag2yqwewan , &
rtB . g3co00rhsr ) ; aghbwax5ws ( rtB . autpxnj4rh , & rtB . dehuj5bzxu ) ; }
gbzgkdr14e = ( uint8_T ) ( ( int32_T ) ( ( uint32_T ) rtB . k3o5ecaomc >> 1 )
& 1 ) ; ea4hitojkb = gbzgkdr14e ; agmbfcn3fg = ( ea4hitojkb != 0 ) ;
ohgc2l5qa2 = ( uint8_T ) ( ( int32_T ) ( ( uint32_T ) rtB . k3o5ecaomc >> 2 )
& 1 ) ; ontveiyunp = ohgc2l5qa2 ; hbx5k5xnzy = ( ontveiyunp != 0 ) ;
UNUSED_PARAMETER ( tid ) ; } void MdlUpdate ( int_T tid ) { int32_T i ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { for ( i = 0 ; i < 42240 ; i ++ ) { rtDW .
htr0gxofmj [ i ] = rtB . ia4sifx1pp . c4qjhbvh3g [ i ] ; rtDW . nzbtkt4pjn [
i + ( rtDW . bsztjvk1v2 == 0 ) * 42240 ] = rtB . oidhnxlzrn [ i ] ; rtDW .
fvq1rooxjr [ i ] = rtB . g3co00rhsr . c4qjhbvh3g [ i ] ; rtDW . ar2gdpszka [
i ] = rtB . dehuj5bzxu . c4qjhbvh3g [ i ] ; } rtDW . bsztjvk1v2 = ( int8_T )
( rtDW . bsztjvk1v2 == 0 ) ; } { struct filcommon_Error_StatusAndMsg *
Error_StatusAndMsg ; static char_T ErrorMsg [ FIL_CAPI_MAX_ERROR_STR ] = "" ;
uint32_T ClassID = ( int32_T ) rtDW . afib14q5zg ; Error_StatusAndMsg = (
struct filcommon_Error_StatusAndMsg * ) rtDW . ewug0yyuyo .
filcommon_Error_StatusAndMsg ; Error_StatusAndMsg -> Status = 0 ;
filcommon_update ( ClassID , Error_StatusAndMsg ) ; if ( Error_StatusAndMsg
-> Status ) { strcpy ( ErrorMsg , Error_StatusAndMsg -> ErrorMsg ) ;
ssSetErrorStatus ( rtS , ErrorMsg ) ; return ; } } aqonbsnzoq ( rtB .
ajmukknkba , rtB . i1hm2nlh3k , & rtDW . mc0ac3mqpt3 ) ; aqonbsnzoq ( rtB .
ajmukknkba , rtB . ihuqv4edg3 , & rtDW . exx2sgg2c1 ) ; aqonbsnzoq ( rtB .
ajmukknkba , rtB . pn3popodna , & rtDW . nwx4oddprh ) ; if ( ssIsSampleHit (
rtS , 1 , 0 ) ) { } UNUSED_PARAMETER ( tid ) ; } void MdlTerminate ( void ) {
char_T * sErr ; { struct filcommon_PortInfoT * InputPortInfoArray ; struct
filcommon_PortInfoT * OutputPortInfoArray ; struct filcommon_BlockInfoT *
BlockInfo_V ; struct filcommon_SoftwareVersionT * SoftwareVersion_V ; struct
filcommon_Error_StatusAndMsg * Error_StatusAndMsg ; static char_T ErrorMsg [
FIL_CAPI_MAX_ERROR_STR ] = "" ; uint32_T ClassID = ( uint32_T ) rtDW .
afib14q5zg ; InputPortInfoArray = ( struct filcommon_PortInfoT * ) rtDW .
ewug0yyuyo . filcommon_PortInfo_Inputs ; OutputPortInfoArray = ( struct
filcommon_PortInfoT * ) rtDW . ewug0yyuyo . filcommon_PortInfo_Outputs ;
BlockInfo_V = ( struct filcommon_BlockInfoT * ) rtDW . ewug0yyuyo .
filcommon_BlockInfoT ; SoftwareVersion_V = ( struct
filcommon_SoftwareVersionT * ) rtDW . ewug0yyuyo . filcommon_SoftwareVersion
; Error_StatusAndMsg = ( struct filcommon_Error_StatusAndMsg * ) rtDW .
ewug0yyuyo . filcommon_Error_StatusAndMsg ; Error_StatusAndMsg -> Status = 0
; if ( InputPortInfoArray != NULL ) { free ( InputPortInfoArray [ 0 ] . name
) ; free ( InputPortInfoArray [ 1 ] . name ) ; free ( InputPortInfoArray [ 2
] . name ) ; free ( InputPortInfoArray [ 3 ] . name ) ; free (
InputPortInfoArray ) ; InputPortInfoArray = NULL ; } if ( OutputPortInfoArray
!= NULL ) { free ( OutputPortInfoArray [ 0 ] . name ) ; free (
OutputPortInfoArray [ 1 ] . name ) ; free ( OutputPortInfoArray [ 2 ] . name
) ; free ( OutputPortInfoArray [ 3 ] . name ) ; free ( OutputPortInfoArray [
4 ] . name ) ; free ( OutputPortInfoArray ) ; OutputPortInfoArray = NULL ; }
if ( BlockInfo_V != NULL ) { free ( BlockInfo_V ) ; BlockInfo_V = NULL ; } if
( SoftwareVersion_V != NULL ) { free ( SoftwareVersion_V ) ;
SoftwareVersion_V = NULL ; } filcommon_terminate ( ClassID ,
Error_StatusAndMsg ) ; if ( Error_StatusAndMsg -> Status ) { strcpy (
ErrorMsg , Error_StatusAndMsg -> ErrorMsg ) ; ssSetErrorStatus ( rtS ,
ErrorMsg ) ; return ; } if ( Error_StatusAndMsg != NULL ) { free (
Error_StatusAndMsg ) ; Error_StatusAndMsg = NULL ; } } sErr = GetErrorBuffer
( & rtDW . gy3colbg2d [ 0U ] ) ; LibTerminate ( & rtDW . gy3colbg2d [ 0U ] )
; if ( * sErr != 0 ) { ssSetErrorStatus ( rtS , sErr ) ; ssSetStopRequested (
rtS , 1 ) ; } LibDestroy ( & rtDW . gy3colbg2d [ 0U ] , 0 ) ;
DestroyHostLibrary ( & rtDW . gy3colbg2d [ 0U ] ) ; { if ( rt_slioCatalogue (
) != ( NULL ) ) { void * * slioCatalogueAddr = rt_slioCatalogueAddr ( ) ;
rtwCreateSigstreamSlioClient ( rt_GetOSigstreamManager ( ) ,
rtwGetPointerFromUniquePtr ( rt_slioCatalogue ( ) ) ) ;
rtwSaveDatasetsToMatFile ( rtwGetPointerFromUniquePtr ( rt_slioCatalogue ( )
) , rt_GetMatSigstreamLoggingFileName ( ) ) ;
rtwOSigstreamManagerDestroyInstance ( rt_GetOSigstreamManager ( ) ) ;
rtwTerminateSlioCatalogue ( slioCatalogueAddr ) ; * slioCatalogueAddr = (
NULL ) ; } } } void MdlInitializeSizes ( void ) { ssSetNumContStates ( rtS ,
0 ) ; ssSetNumY ( rtS , 0 ) ; ssSetNumU ( rtS , 0 ) ; ssSetDirectFeedThrough
( rtS , 0 ) ; ssSetNumSampleTimes ( rtS , 2 ) ; ssSetNumBlocks ( rtS , 66 ) ;
ssSetNumBlockIO ( rtS , 37 ) ; ssSetNumBlockParams ( rtS , 15 ) ; } void
MdlInitializeSampleTimes ( void ) { ssSetSampleTime ( rtS , 0 ,
9.8642676767676768E-7 ) ; ssSetSampleTime ( rtS , 1 , 0.041666666666666664 )
; ssSetOffsetTime ( rtS , 0 , 0.0 ) ; ssSetOffsetTime ( rtS , 1 , 0.0 ) ; }
void raccel_set_checksum ( SimStruct * rtS ) { ssSetChecksumVal ( rtS , 0 ,
171571849U ) ; ssSetChecksumVal ( rtS , 1 , 1712919735U ) ; ssSetChecksumVal
( rtS , 2 , 3436261685U ) ; ssSetChecksumVal ( rtS , 3 , 2463775248U ) ; }
SimStruct * raccel_register_model ( void ) { static struct _ssMdlInfo mdlInfo
; ( void ) memset ( ( char * ) rtS , 0 , sizeof ( SimStruct ) ) ; ( void )
memset ( ( char * ) & mdlInfo , 0 , sizeof ( struct _ssMdlInfo ) ) ;
ssSetMdlInfoPtr ( rtS , & mdlInfo ) ; { static time_T mdlPeriod [
NSAMPLE_TIMES ] ; static time_T mdlOffset [ NSAMPLE_TIMES ] ; static time_T
mdlTaskTimes [ NSAMPLE_TIMES ] ; static int_T mdlTsMap [ NSAMPLE_TIMES ] ;
static int_T mdlSampleHits [ NSAMPLE_TIMES ] ; static boolean_T
mdlTNextWasAdjustedPtr [ NSAMPLE_TIMES ] ; static int_T mdlPerTaskSampleHits
[ NSAMPLE_TIMES * NSAMPLE_TIMES ] ; static time_T mdlTimeOfNextSampleHit [
NSAMPLE_TIMES ] ; { int_T i ; for ( i = 0 ; i < NSAMPLE_TIMES ; i ++ ) {
mdlPeriod [ i ] = 0.0 ; mdlOffset [ i ] = 0.0 ; mdlTaskTimes [ i ] = 0.0 ;
mdlTsMap [ i ] = i ; mdlSampleHits [ i ] = 1 ; } } ssSetSampleTimePtr ( rtS ,
& mdlPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rtS , & mdlOffset [ 0 ] ) ;
ssSetSampleTimeTaskIDPtr ( rtS , & mdlTsMap [ 0 ] ) ; ssSetTPtr ( rtS , &
mdlTaskTimes [ 0 ] ) ; ssSetSampleHitPtr ( rtS , & mdlSampleHits [ 0 ] ) ;
ssSetTNextWasAdjustedPtr ( rtS , & mdlTNextWasAdjustedPtr [ 0 ] ) ;
ssSetPerTaskSampleHitsPtr ( rtS , & mdlPerTaskSampleHits [ 0 ] ) ;
ssSetTimeOfNextSampleHitPtr ( rtS , & mdlTimeOfNextSampleHit [ 0 ] ) ; }
ssSetSolverMode ( rtS , SOLVER_MODE_SINGLETASKING ) ; { ssSetBlockIO ( rtS ,
( ( void * ) & rtB ) ) ; ( void ) memset ( ( ( void * ) & rtB ) , 0 , sizeof
( B ) ) ; } ssSetDefaultParam ( rtS , ( real_T * ) & rtP ) ; { void * dwork =
( void * ) & rtDW ; ssSetRootDWork ( rtS , dwork ) ; ( void ) memset ( dwork
, 0 , sizeof ( DW ) ) ; rtDW . cfvviahwgs = 0.0 ; rtDW . nf53pai11t = 0.0 ;
rtDW . btv0brqgud = 0.0 ; { int32_T i ; for ( i = 0 ; i < 137 ; i ++ ) { rtDW
. gy3colbg2d [ i ] = 0.0 ; } } { int32_T i ; for ( i = 0 ; i < 5 ; i ++ ) {
rtDW . nuoi2bpcqb [ i ] = 0.0 ; } } { int32_T i ; for ( i = 0 ; i < 11 ; i ++
) { rtDW . kobal3a2ry [ i ] = 0.0 ; } } rtDW . kixhks45oc = 0.0 ; rtDW .
p3f52jnckb = 0.0 ; rtDW . msngf5zymf = 0.0 ; } { static DataTypeTransInfo
dtInfo ; ( void ) memset ( ( char_T * ) & dtInfo , 0 , sizeof ( dtInfo ) ) ;
ssSetModelMappingInfo ( rtS , & dtInfo ) ; dtInfo . numDataTypes = 20 ;
dtInfo . dataTypeSizes = & rtDataTypeSizes [ 0 ] ; dtInfo . dataTypeNames = &
rtDataTypeNames [ 0 ] ; dtInfo . BTransTable = & rtBTransTable ; dtInfo .
PTransTable = & rtPTransTable ; } fil_videosharp_sim_InitializeDataMapInfo (
) ; ssSetIsRapidAcceleratorActive ( rtS , true ) ; ssSetRootSS ( rtS , rtS )
; ssSetVersion ( rtS , SIMSTRUCT_VERSION_LEVEL2 ) ; ssSetModelName ( rtS ,
"fil_videosharp_sim" ) ; ssSetPath ( rtS , "fil_videosharp_sim" ) ;
ssSetTStart ( rtS , 0.0 ) ; ssSetTFinal ( rtS , 10.0 ) ; ssSetStepSize ( rtS
, 9.8642676767676768E-7 ) ; ssSetFixedStepSize ( rtS , 9.8642676767676768E-7
) ; { static RTWLogInfo rt_DataLoggingInfo ; rt_DataLoggingInfo .
loggingInterval = NULL ; ssSetRTWLogInfo ( rtS , & rt_DataLoggingInfo ) ; } {
{ static int_T rt_LoggedStateWidths [ ] = { 1 , 1 , 1 , 42240 , 42240 , 42240
, 42240 , 42240 , 42240 , 1 , 42240 , 1 , 42240 , 1 , 42240 } ; static int_T
rt_LoggedStateNumDimensions [ ] = { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1
, 1 , 1 , 1 , 1 } ; static int_T rt_LoggedStateDimensions [ ] = { 1 , 1 , 1 ,
42240 , 42240 , 42240 , 42240 , 42240 , 42240 , 1 , 42240 , 1 , 42240 , 1 ,
42240 } ; static boolean_T rt_LoggedStateIsVarDims [ ] = { 0 , 0 , 0 , 0 , 0
, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } ; static BuiltInDTypeId
rt_LoggedStateDataTypeIds [ ] = { SS_INT32 , SS_INT32 , SS_INT32 , SS_UINT8 ,
SS_UINT8 , SS_UINT8 , SS_UINT8 , SS_UINT8 , SS_UINT8 , SS_INT32 , SS_UINT8 ,
SS_INT32 , SS_UINT8 , SS_INT32 , SS_UINT8 } ; static int_T
rt_LoggedStateComplexSignals [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 , 0 , 0 } ; static const char_T * rt_LoggedStateLabels [ ] = {
"memIdx" , "memIdx" , "memIdx" , "DSTATE" , "CircBuff" , "DSTATE" ,
"CircBuff" , "DSTATE" , "CircBuff" , "BUFF_OFFSET" , "Buff" , "BUFF_OFFSET" ,
"Buff" , "BUFF_OFFSET" , "Buff" } ; static const char_T *
rt_LoggedStateBlockNames [ ] = {
"fil_videosharp_sim/Frame to Stream/Unbuffer" ,
"fil_videosharp_sim/Frame to Stream/Unbuffer1" ,
"fil_videosharp_sim/Frame to Stream/Unbuffer2" ,
 "fil_videosharp_sim/Frame to Stream/Convert to\nColumn Vector/Balance\nLatencies"
, "fil_videosharp_sim/Frame to Stream/Unbuffer" ,
 "fil_videosharp_sim/Frame to Stream/Convert to\nColumn Vector1/Balance\nLatencies"
, "fil_videosharp_sim/Frame to Stream/Unbuffer1" ,
 "fil_videosharp_sim/Frame to Stream/Convert to\nColumn Vector2/Balance\nLatencies"
, "fil_videosharp_sim/Frame to Stream/Unbuffer2" ,
"fil_videosharp_sim/Stream to Frame/Buffer Data2/Delay Line" ,
"fil_videosharp_sim/Stream to Frame/Buffer Data2/Delay Line" ,
"fil_videosharp_sim/Stream to Frame/Buffer Data1/Delay Line" ,
"fil_videosharp_sim/Stream to Frame/Buffer Data1/Delay Line" ,
"fil_videosharp_sim/Stream to Frame/Buffer Data/Delay Line" ,
"fil_videosharp_sim/Stream to Frame/Buffer Data/Delay Line" } ; static const
char_T * rt_LoggedStateNames [ ] = { "" , "" , "" , "" , "" , "" , "" , "" ,
"" , "" , "" , "" , "" , "" , "" } ; static boolean_T
rt_LoggedStateCrossMdlRef [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 , 0 } ; static RTWLogDataTypeConvert rt_RTWLogDataTypeConvert [ ] =
{ { 0 , SS_INT32 , SS_INT32 , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_INT32 ,
SS_INT32 , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_INT32 , SS_INT32 , 0 , 0 ,
0 , 1.0 , 0 , 0.0 } , { 0 , SS_UINT8 , SS_UINT8 , 0 , 0 , 0 , 1.0 , 0 , 0.0 }
, { 0 , SS_UINT8 , SS_UINT8 , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_UINT8 ,
SS_UINT8 , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_UINT8 , SS_UINT8 , 0 , 0 ,
0 , 1.0 , 0 , 0.0 } , { 0 , SS_UINT8 , SS_UINT8 , 0 , 0 , 0 , 1.0 , 0 , 0.0 }
, { 0 , SS_UINT8 , SS_UINT8 , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_INT32 ,
SS_INT32 , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_UINT8 , SS_UINT8 , 0 , 0 ,
0 , 1.0 , 0 , 0.0 } , { 0 , SS_INT32 , SS_INT32 , 0 , 0 , 0 , 1.0 , 0 , 0.0 }
, { 0 , SS_UINT8 , SS_UINT8 , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_INT32 ,
SS_INT32 , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_UINT8 , SS_UINT8 , 0 , 0 ,
0 , 1.0 , 0 , 0.0 } } ; static RTWLogSignalInfo rt_LoggedStateSignalInfo = {
15 , rt_LoggedStateWidths , rt_LoggedStateNumDimensions ,
rt_LoggedStateDimensions , rt_LoggedStateIsVarDims , ( NULL ) , ( NULL ) ,
rt_LoggedStateDataTypeIds , rt_LoggedStateComplexSignals , ( NULL ) , {
rt_LoggedStateLabels } , ( NULL ) , ( NULL ) , ( NULL ) , {
rt_LoggedStateBlockNames } , { rt_LoggedStateNames } ,
rt_LoggedStateCrossMdlRef , rt_RTWLogDataTypeConvert } ; static void *
rt_LoggedStateSignalPtrs [ 15 ] ; rtliSetLogXSignalPtrs ( ssGetRTWLogInfo (
rtS ) , ( LogSignalPtrsType ) rt_LoggedStateSignalPtrs ) ;
rtliSetLogXSignalInfo ( ssGetRTWLogInfo ( rtS ) , & rt_LoggedStateSignalInfo
) ; rt_LoggedStateSignalPtrs [ 0 ] = ( void * ) & rtDW . l0wyyt10jc ;
rt_LoggedStateSignalPtrs [ 1 ] = ( void * ) & rtDW . k0hbnlu5x1 ;
rt_LoggedStateSignalPtrs [ 2 ] = ( void * ) & rtDW . ktnony3hbz ;
rt_LoggedStateSignalPtrs [ 3 ] = ( void * ) rtDW . htr0gxofmj ;
rt_LoggedStateSignalPtrs [ 4 ] = ( void * ) rtDW . i3atoxqjmk ;
rt_LoggedStateSignalPtrs [ 5 ] = ( void * ) rtDW . fvq1rooxjr ;
rt_LoggedStateSignalPtrs [ 6 ] = ( void * ) rtDW . ovazadzx53 ;
rt_LoggedStateSignalPtrs [ 7 ] = ( void * ) rtDW . ar2gdpszka ;
rt_LoggedStateSignalPtrs [ 8 ] = ( void * ) rtDW . b5fsf4ugkz ;
rt_LoggedStateSignalPtrs [ 9 ] = ( void * ) & rtDW . nwx4oddprh . bolnweqpxw
; rt_LoggedStateSignalPtrs [ 10 ] = ( void * ) rtDW . nwx4oddprh . akoskppbih
; rt_LoggedStateSignalPtrs [ 11 ] = ( void * ) & rtDW . exx2sgg2c1 .
bolnweqpxw ; rt_LoggedStateSignalPtrs [ 12 ] = ( void * ) rtDW . exx2sgg2c1 .
akoskppbih ; rt_LoggedStateSignalPtrs [ 13 ] = ( void * ) & rtDW .
mc0ac3mqpt3 . bolnweqpxw ; rt_LoggedStateSignalPtrs [ 14 ] = ( void * ) rtDW
. mc0ac3mqpt3 . akoskppbih ; } rtliSetLogT ( ssGetRTWLogInfo ( rtS ) , "tout"
) ; rtliSetLogX ( ssGetRTWLogInfo ( rtS ) , "tmp_raccel_xout" ) ;
rtliSetLogXFinal ( ssGetRTWLogInfo ( rtS ) , "xFinal" ) ;
rtliSetLogVarNameModifier ( ssGetRTWLogInfo ( rtS ) , "none" ) ;
rtliSetLogFormat ( ssGetRTWLogInfo ( rtS ) , 2 ) ; rtliSetLogMaxRows (
ssGetRTWLogInfo ( rtS ) , 1000 ) ; rtliSetLogDecimation ( ssGetRTWLogInfo (
rtS ) , 1 ) ; rtliSetLogY ( ssGetRTWLogInfo ( rtS ) , "" ) ;
rtliSetLogYSignalInfo ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ;
rtliSetLogYSignalPtrs ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ; } { static
struct _ssStatesInfo2 statesInfo2 ; ssSetStatesInfo2 ( rtS , & statesInfo2 )
; } { static ssPeriodicStatesInfo periodicStatesInfo ;
ssSetPeriodicStatesInfo ( rtS , & periodicStatesInfo ) ; } { static
ssSolverInfo slvrInfo ; ssSetSolverInfo ( rtS , & slvrInfo ) ;
ssSetSolverName ( rtS , "FixedStepDiscrete" ) ; ssSetVariableStepSolver ( rtS
, 0 ) ; ssSetSolverConsistencyChecking ( rtS , 0 ) ;
ssSetSolverAdaptiveZcDetection ( rtS , 0 ) ; ssSetSolverRobustResetMethod (
rtS , 0 ) ; ssSetSolverStateProjection ( rtS , 0 ) ;
ssSetSolverMassMatrixType ( rtS , ( ssMatrixType ) 0 ) ;
ssSetSolverMassMatrixNzMax ( rtS , 0 ) ; ssSetModelOutputs ( rtS , MdlOutputs
) ; ssSetModelLogData ( rtS , rt_UpdateTXYLogVars ) ;
ssSetModelLogDataIfInInterval ( rtS , rt_UpdateTXXFYLogVars ) ;
ssSetModelUpdate ( rtS , MdlUpdate ) ; ssSetTNextTid ( rtS , INT_MIN ) ;
ssSetTNext ( rtS , rtMinusInf ) ; ssSetSolverNeedsReset ( rtS ) ;
ssSetNumNonsampledZCs ( rtS , 0 ) ; } { ZCSigState * zc = ( ZCSigState * ) &
rtPrevZCX ; ssSetPrevZCSigState ( rtS , zc ) ; } { rtPrevZCX . d1lln4iu3m .
cclksiqhzv = POS_ZCSIG ; rtPrevZCX . bosgivqpz4 . cclksiqhzv = POS_ZCSIG ;
rtPrevZCX . ildclrdm44a . cclksiqhzv = POS_ZCSIG ; } ssSetChecksumVal ( rtS ,
0 , 171571849U ) ; ssSetChecksumVal ( rtS , 1 , 1712919735U ) ;
ssSetChecksumVal ( rtS , 2 , 3436261685U ) ; ssSetChecksumVal ( rtS , 3 ,
2463775248U ) ; { static const sysRanDType rtAlwaysEnabled =
SUBSYS_RAN_BC_ENABLE ; static RTWExtModeInfo rt_ExtModeInfo ; static const
sysRanDType * systemRan [ 12 ] ; gblRTWExtModeInfo = & rt_ExtModeInfo ;
ssSetRTWExtModeInfo ( rtS , & rt_ExtModeInfo ) ;
rteiSetSubSystemActiveVectorAddresses ( & rt_ExtModeInfo , systemRan ) ;
systemRan [ 0 ] = & rtAlwaysEnabled ; systemRan [ 1 ] = & rtAlwaysEnabled ;
systemRan [ 2 ] = & rtAlwaysEnabled ; systemRan [ 3 ] = & rtAlwaysEnabled ;
systemRan [ 4 ] = & rtAlwaysEnabled ; systemRan [ 5 ] = ( sysRanDType * ) &
rtDW . mc0ac3mqpt3 . nzofjgicqg ; systemRan [ 6 ] = ( sysRanDType * ) & rtDW
. exx2sgg2c1 . nzofjgicqg ; systemRan [ 7 ] = ( sysRanDType * ) & rtDW .
nwx4oddprh . nzofjgicqg ; systemRan [ 8 ] = ( sysRanDType * ) & rtDW .
ildclrdm44a . lfya5jsxdb ; systemRan [ 9 ] = ( sysRanDType * ) & rtDW .
bosgivqpz4 . lfya5jsxdb ; systemRan [ 10 ] = ( sysRanDType * ) & rtDW .
d1lln4iu3m . lfya5jsxdb ; systemRan [ 11 ] = & rtAlwaysEnabled ;
rteiSetModelMappingInfoPtr ( ssGetRTWExtModeInfo ( rtS ) , &
ssGetModelMappingInfo ( rtS ) ) ; rteiSetChecksumsPtr ( ssGetRTWExtModeInfo (
rtS ) , ssGetChecksums ( rtS ) ) ; rteiSetTPtr ( ssGetRTWExtModeInfo ( rtS )
, ssGetTPtr ( rtS ) ) ; } return rtS ; } const int_T gblParameterTuningTid =
- 1 ; void MdlOutputsParameterSampleTime ( int_T tid ) { UNUSED_PARAMETER (
tid ) ; }
