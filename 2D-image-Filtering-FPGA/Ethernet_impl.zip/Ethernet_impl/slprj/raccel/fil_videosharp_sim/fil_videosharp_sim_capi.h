#include "__cf_fil_videosharp_sim.h"
#ifndef RTW_HEADER_fil_videosharp_sim_capi_h
#define RTW_HEADER_fil_videosharp_sim_capi_h
#include "fil_videosharp_sim.h"
extern void fil_videosharp_sim_InitializeDataMapInfo ( ) ;
#endif
