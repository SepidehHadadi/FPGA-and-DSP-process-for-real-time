#include "__cf_fil_videosharp_sim.h"
#include "ext_types.h"
static uint_T rtDataTypeSizes [ ] = { sizeof ( real_T ) , sizeof ( real32_T )
, sizeof ( int8_T ) , sizeof ( uint8_T ) , sizeof ( int16_T ) , sizeof (
uint16_T ) , sizeof ( int32_T ) , sizeof ( uint32_T ) , sizeof ( boolean_T )
, sizeof ( fcn_call_T ) , sizeof ( int_T ) , sizeof ( pointer_T ) , sizeof (
action_T ) , 2 * sizeof ( uint32_T ) , sizeof ( uint8_T ) , sizeof ( uint8_T
) , sizeof ( uint8_T ) , sizeof ( uint8_T ) , sizeof ( uint8_T ) , sizeof (
uint8_T ) } ; static const char_T * rtDataTypeNames [ ] = { "real_T" ,
"real32_T" , "int8_T" , "uint8_T" , "int16_T" , "uint16_T" , "int32_T" ,
"uint32_T" , "boolean_T" , "fcn_call_T" , "int_T" , "pointer_T" , "action_T"
, "timer_uint32_pair_T" , "uint8_T" , "uint8_T" , "uint8_T" , "uint8_T" ,
"uint8_T" , "uint8_T" } ; static DataTypeTransition rtBTransitions [ ] = { {
( char_T * ) ( & rtB . o5wnfdweb1 [ 0 ] ) , 3 , 0 , 675846 } , { ( char_T * )
( & rtB . mqkcirpnav ) , 8 , 0 , 2 } , { ( char_T * ) ( & rtB . bjwgh3zhq3 )
, 14 , 0 , 3 } , { ( char_T * ) ( & rtB . d1lln4iu3m . ljwteyu2qv [ 0 ] ) , 3
, 0 , 42240 } , { ( char_T * ) ( & rtB . bosgivqpz4 . ljwteyu2qv [ 0 ] ) , 3
, 0 , 42240 } , { ( char_T * ) ( & rtB . ildclrdm44a . ljwteyu2qv [ 0 ] ) , 3
, 0 , 42240 } , { ( char_T * ) ( & rtB . nwx4oddprh . cpoh2looqz [ 0 ] ) , 3
, 0 , 42240 } , { ( char_T * ) ( & rtB . exx2sgg2c1 . cpoh2looqz [ 0 ] ) , 3
, 0 , 42240 } , { ( char_T * ) ( & rtB . mc0ac3mqpt3 . cpoh2looqz [ 0 ] ) , 3
, 0 , 42240 } , { ( char_T * ) ( & rtB . dehuj5bzxu . c4qjhbvh3g [ 0 ] ) , 3
, 0 , 42240 } , { ( char_T * ) ( & rtB . g3co00rhsr . c4qjhbvh3g [ 0 ] ) , 3
, 0 , 42240 } , { ( char_T * ) ( & rtB . ia4sifx1pp . c4qjhbvh3g [ 0 ] ) , 3
, 0 , 42240 } , { ( char_T * ) ( & rtDW . cfvviahwgs ) , 0 , 0 , 159 } , { (
char_T * ) ( & rtDW . ewug0yyuyo . filcommon_PortInfo_Inputs ) , 11 , 0 , 1 }
, { ( char_T * ) ( & rtDW . l0wyyt10jc ) , 6 , 0 , 3 } , { ( char_T * ) ( &
rtDW . afib14q5zg ) , 7 , 0 , 1 } , { ( char_T * ) ( & rtDW . htr0gxofmj [ 0
] ) , 3 , 0 , 253440 } , { ( char_T * ) ( & rtDW . bsztjvk1v2 ) , 2 , 0 , 1 }
, { ( char_T * ) ( & rtDW . nzbtkt4pjn [ 0 ] ) , 3 , 0 , 190080 } , { (
char_T * ) ( & rtDW . arufmtcy3m ) , 8 , 0 , 1 } , { ( char_T * ) ( & rtDW .
d1lln4iu3m . lfya5jsxdb ) , 2 , 0 , 1 } , { ( char_T * ) ( & rtDW .
bosgivqpz4 . lfya5jsxdb ) , 2 , 0 , 1 } , { ( char_T * ) ( & rtDW .
ildclrdm44a . lfya5jsxdb ) , 2 , 0 , 1 } , { ( char_T * ) ( & rtDW .
nwx4oddprh . bolnweqpxw ) , 6 , 0 , 1 } , { ( char_T * ) ( & rtDW .
nwx4oddprh . akoskppbih [ 0 ] ) , 3 , 0 , 42240 } , { ( char_T * ) ( & rtDW .
nwx4oddprh . nzofjgicqg ) , 2 , 0 , 1 } , { ( char_T * ) ( & rtDW .
exx2sgg2c1 . bolnweqpxw ) , 6 , 0 , 1 } , { ( char_T * ) ( & rtDW .
exx2sgg2c1 . akoskppbih [ 0 ] ) , 3 , 0 , 42240 } , { ( char_T * ) ( & rtDW .
exx2sgg2c1 . nzofjgicqg ) , 2 , 0 , 1 } , { ( char_T * ) ( & rtDW .
mc0ac3mqpt3 . bolnweqpxw ) , 6 , 0 , 1 } , { ( char_T * ) ( & rtDW .
mc0ac3mqpt3 . akoskppbih [ 0 ] ) , 3 , 0 , 42240 } , { ( char_T * ) ( & rtDW
. mc0ac3mqpt3 . nzofjgicqg ) , 2 , 0 , 1 } } ; static DataTypeTransitionTable
rtBTransTable = { 32U , rtBTransitions } ; static DataTypeTransition
rtPTransitions [ ] = { { ( char_T * ) ( & rtP . BalanceLatencies_DelayLength
) , 3 , 0 , 15 } } ; static DataTypeTransitionTable rtPTransTable = { 1U ,
rtPTransitions } ;
