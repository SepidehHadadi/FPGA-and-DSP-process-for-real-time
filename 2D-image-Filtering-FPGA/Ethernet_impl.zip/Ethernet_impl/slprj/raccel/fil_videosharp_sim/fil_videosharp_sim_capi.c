#include "__cf_fil_videosharp_sim.h"
#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "fil_videosharp_sim_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)    
#else
#include "builtin_typeid_types.h"
#include "fil_videosharp_sim.h"
#include "fil_videosharp_sim_capi.h"
#include "fil_videosharp_sim_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST                  
#define TARGET_STRING(s)               (NULL)                    
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static const rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 0 , TARGET_STRING (
"fil_videosharp_sim/Chroma Resampling" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 1 , 0 , TARGET_STRING ( "fil_videosharp_sim/Chroma Resampling" )
, TARGET_STRING ( "" ) , 1 , 0 , 0 , 0 , 0 } , { 2 , 0 , TARGET_STRING (
"fil_videosharp_sim/Color Space  Conversion1" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 3 , 0 , TARGET_STRING (
"fil_videosharp_sim/Color Space  Conversion1" ) , TARGET_STRING ( "" ) , 1 ,
0 , 0 , 0 , 0 } , { 4 , 0 , TARGET_STRING (
"fil_videosharp_sim/Color Space  Conversion1" ) , TARGET_STRING ( "" ) , 2 ,
0 , 0 , 0 , 0 } , { 5 , 0 , TARGET_STRING (
"fil_videosharp_sim/Color Space  Conversion2" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 6 , 0 , TARGET_STRING (
"fil_videosharp_sim/Color Space  Conversion2" ) , TARGET_STRING ( "" ) , 1 ,
0 , 0 , 0 , 0 } , { 7 , 0 , TARGET_STRING (
"fil_videosharp_sim/Color Space  Conversion2" ) , TARGET_STRING ( "" ) , 2 ,
0 , 0 , 0 , 0 } , { 8 , 0 , TARGET_STRING (
"fil_videosharp_sim/From Multimedia File" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 9 , 0 , TARGET_STRING (
"fil_videosharp_sim/From Multimedia File" ) , TARGET_STRING ( "" ) , 1 , 0 ,
1 , 0 , 0 } , { 10 , 0 , TARGET_STRING (
"fil_videosharp_sim/From Multimedia File" ) , TARGET_STRING ( "" ) , 2 , 0 ,
1 , 0 , 0 } , { 11 , 0 , TARGET_STRING (
"fil_videosharp_sim/Streaming_2_D_FIR_Filter" ) , TARGET_STRING ( "" ) , 0 ,
0 , 2 , 1 , 1 } , { 12 , 0 , TARGET_STRING (
"fil_videosharp_sim/Streaming_2_D_FIR_Filter" ) , TARGET_STRING ( "" ) , 1 ,
0 , 2 , 2 , 1 } , { 13 , 0 , TARGET_STRING (
"fil_videosharp_sim/Streaming_2_D_FIR_Filter" ) , TARGET_STRING ( "" ) , 2 ,
0 , 2 , 0 , 1 } , { 14 , 0 , TARGET_STRING (
"fil_videosharp_sim/Streaming_2_D_FIR_Filter" ) , TARGET_STRING ( "" ) , 3 ,
0 , 2 , 0 , 1 } , { 15 , 0 , TARGET_STRING (
"fil_videosharp_sim/Streaming_2_D_FIR_Filter" ) , TARGET_STRING ( "" ) , 4 ,
0 , 2 , 0 , 1 } , { 16 , 2 , TARGET_STRING (
 "fil_videosharp_sim/Frame to Stream/Produce Row-Major Organized Output (Dimensions will be flipped)"
) , TARGET_STRING ( "" ) , 0 , 0 , 3 , 0 , 0 } , { 17 , 3 , TARGET_STRING (
 "fil_videosharp_sim/Frame to Stream/Produce Row-Major Organized Output (Dimensions will be flipped)1"
) , TARGET_STRING ( "" ) , 0 , 0 , 3 , 0 , 0 } , { 18 , 4 , TARGET_STRING (
 "fil_videosharp_sim/Frame to Stream/Produce Row-Major Organized Output (Dimensions will be flipped)2"
) , TARGET_STRING ( "" ) , 0 , 0 , 3 , 0 , 0 } , { 19 , 0 , TARGET_STRING (
"fil_videosharp_sim/Frame to Stream/Sum of Elements" ) , TARGET_STRING ( "" )
, 0 , 0 , 2 , 2 , 1 } , { 20 , 0 , TARGET_STRING (
"fil_videosharp_sim/Frame to Stream/Unbuffer" ) , TARGET_STRING ( "" ) , 0 ,
0 , 2 , 0 , 1 } , { 21 , 0 , TARGET_STRING (
"fil_videosharp_sim/Frame to Stream/Unbuffer1" ) , TARGET_STRING ( "" ) , 0 ,
0 , 2 , 0 , 1 } , { 22 , 0 , TARGET_STRING (
"fil_videosharp_sim/Frame to Stream/Unbuffer2" ) , TARGET_STRING ( "" ) , 0 ,
0 , 2 , 0 , 1 } , { 23 , 5 , TARGET_STRING (
"fil_videosharp_sim/Stream to Frame/Buffer Data" ) , TARGET_STRING ( "" ) , 0
, 0 , 4 , 0 , 2 } , { 24 , 6 , TARGET_STRING (
"fil_videosharp_sim/Stream to Frame/Buffer Data1" ) , TARGET_STRING ( "" ) ,
0 , 0 , 4 , 0 , 2 } , { 25 , 7 , TARGET_STRING (
"fil_videosharp_sim/Stream to Frame/Buffer Data2" ) , TARGET_STRING ( "" ) ,
0 , 0 , 4 , 0 , 2 } , { 26 , 8 , TARGET_STRING (
"fil_videosharp_sim/Stream to Frame/Capture Full Frame" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 3 } , { 27 , 9 , TARGET_STRING (
"fil_videosharp_sim/Stream to Frame/Capture Full Frame1" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 3 } , { 28 , 10 , TARGET_STRING (
"fil_videosharp_sim/Stream to Frame/Capture Full Frame2" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 3 } , { 29 , 11 , TARGET_STRING (
"fil_videosharp_sim/Stream to Frame/Generate Control Signals" ) ,
TARGET_STRING ( "" ) , 0 , 1 , 2 , 0 , 1 } , { 30 , 11 , TARGET_STRING (
"fil_videosharp_sim/Stream to Frame/Generate Control Signals" ) ,
TARGET_STRING ( "" ) , 1 , 1 , 2 , 0 , 1 } , { 31 , 0 , TARGET_STRING (
"fil_videosharp_sim/Stream to Frame/Rate Transition" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 0 } , { 32 , 0 , TARGET_STRING (
"fil_videosharp_sim/Stream to Frame/Rate Transition1" ) , TARGET_STRING ( ""
) , 0 , 0 , 0 , 0 , 0 } , { 33 , 0 , TARGET_STRING (
"fil_videosharp_sim/Stream to Frame/Rate Transition2" ) , TARGET_STRING ( ""
) , 0 , 0 , 0 , 0 , 0 } , { 34 , 5 , TARGET_STRING (
"fil_videosharp_sim/Stream to Frame/Buffer Data/Delay Line" ) , TARGET_STRING
( "" ) , 0 , 0 , 4 , 0 , 2 } , { 35 , 6 , TARGET_STRING (
"fil_videosharp_sim/Stream to Frame/Buffer Data1/Delay Line" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 4 , 0 , 2 } , { 36 , 7 , TARGET_STRING (
"fil_videosharp_sim/Stream to Frame/Buffer Data2/Delay Line" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 4 , 0 , 2 } , { 37 , 8 , TARGET_STRING (
"fil_videosharp_sim/Stream to Frame/Capture Full Frame/Permute Dimensions" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 3 } , { 38 , 9 , TARGET_STRING (
"fil_videosharp_sim/Stream to Frame/Capture Full Frame1/Permute Dimensions" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 3 } , { 39 , 10 , TARGET_STRING (
"fil_videosharp_sim/Stream to Frame/Capture Full Frame2/Permute Dimensions" )
, TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 3 } , { 40 , 0 , TARGET_STRING (
 "fil_videosharp_sim/Frame to Stream/Convert to Column Vector/Convert 2-D to 1-D/Reshape"
) , TARGET_STRING ( "" ) , 0 , 0 , 5 , 0 , 0 } , { 41 , 0 , TARGET_STRING (
 "fil_videosharp_sim/Frame to Stream/Convert to Column Vector1/Convert 2-D to 1-D/Reshape"
) , TARGET_STRING ( "" ) , 0 , 0 , 5 , 0 , 0 } , { 42 , 0 , TARGET_STRING (
 "fil_videosharp_sim/Frame to Stream/Convert to Column Vector2/Convert 2-D to 1-D/Reshape"
) , TARGET_STRING ( "" ) , 0 , 0 , 5 , 0 , 0 } , { 0 , 0 , ( NULL ) , ( NULL
) , 0 , 0 , 0 , 0 , 0 } } ; static const rtwCAPI_BlockParameters
rtBlockParameters [ ] = { { 43 , TARGET_STRING (
"fil_videosharp_sim/Frame to Stream/Gain" ) , TARGET_STRING ( "Gain" ) , 0 ,
6 , 2 } , { 44 , TARGET_STRING (
"fil_videosharp_sim/Frame to Stream/Rate Transition2" ) , TARGET_STRING (
"X0" ) , 0 , 2 , 0 } , { 45 , TARGET_STRING (
"fil_videosharp_sim/Frame to Stream/Unbuffer" ) , TARGET_STRING ( "ic" ) , 0
, 2 , 0 } , { 46 , TARGET_STRING (
"fil_videosharp_sim/Frame to Stream/Unbuffer1" ) , TARGET_STRING ( "ic" ) , 0
, 2 , 0 } , { 47 , TARGET_STRING (
"fil_videosharp_sim/Frame to Stream/Unbuffer2" ) , TARGET_STRING ( "ic" ) , 0
, 2 , 0 } , { 48 , TARGET_STRING (
"fil_videosharp_sim/Frame to Stream/Convert to Column Vector/Balance Latencies"
) , TARGET_STRING ( "DelayLength" ) , 0 , 2 , 0 } , { 49 , TARGET_STRING (
"fil_videosharp_sim/Frame to Stream/Convert to Column Vector/Balance Latencies"
) , TARGET_STRING ( "InitialCondition" ) , 0 , 2 , 0 } , { 50 , TARGET_STRING
(
"fil_videosharp_sim/Frame to Stream/Convert to Column Vector1/Balance Latencies"
) , TARGET_STRING ( "DelayLength" ) , 0 , 2 , 0 } , { 51 , TARGET_STRING (
"fil_videosharp_sim/Frame to Stream/Convert to Column Vector1/Balance Latencies"
) , TARGET_STRING ( "InitialCondition" ) , 0 , 2 , 0 } , { 52 , TARGET_STRING
(
"fil_videosharp_sim/Frame to Stream/Convert to Column Vector2/Balance Latencies"
) , TARGET_STRING ( "DelayLength" ) , 0 , 2 , 0 } , { 53 , TARGET_STRING (
"fil_videosharp_sim/Frame to Stream/Convert to Column Vector2/Balance Latencies"
) , TARGET_STRING ( "InitialCondition" ) , 0 , 2 , 0 } , { 0 , ( NULL ) , (
NULL ) , 0 , 0 , 0 } } ; static const rtwCAPI_ModelParameters
rtModelParameters [ ] = { { 0 , ( NULL ) , 0 , 0 , 0 } } ;
#ifndef HOST_CAPI_BUILD
static void * rtDataAddrMap [ ] = { & rtB . ag2yqwewan [ 0 ] , & rtB .
autpxnj4rh [ 0 ] , & rtB . iqyh2bdr3j [ 0 ] , & rtB . g3tjfoemzo [ 0 ] , &
rtB . cedr240vrj [ 0 ] , & rtB . jb4bvh2jg0 [ 0 ] , & rtB . hpum20ybfk [ 0 ]
, & rtB . ei330voctg [ 0 ] , & rtB . oidhnxlzrn [ 0 ] , & rtB . bo4f3pqa3k [
0 ] , & rtB . jpemu0m5jb [ 0 ] , & rtB . ndclinny1v , & rtB . k3o5ecaomc , &
rtB . i1hm2nlh3k , & rtB . ihuqv4edg3 , & rtB . pn3popodna , & rtB .
ia4sifx1pp . c4qjhbvh3g [ 0 ] , & rtB . g3co00rhsr . c4qjhbvh3g [ 0 ] , & rtB
. dehuj5bzxu . c4qjhbvh3g [ 0 ] , & rtB . bjwgh3zhq3 , & rtB . ph2ms1w2gh , &
rtB . klxyj2wepv , & rtB . grqrubiaoy , & rtB . mc0ac3mqpt3 . cpoh2looqz [ 0
] , & rtB . exx2sgg2c1 . cpoh2looqz [ 0 ] , & rtB . nwx4oddprh . cpoh2looqz [
0 ] , & rtB . ildclrdm44a . ljwteyu2qv [ 0 ] , & rtB . bosgivqpz4 .
ljwteyu2qv [ 0 ] , & rtB . d1lln4iu3m . ljwteyu2qv [ 0 ] , & rtB . mqkcirpnav
, & rtB . ajmukknkba , & rtB . jf2vo3oy2f [ 0 ] , & rtB . ibjdq010lc [ 0 ] ,
& rtB . fnt5vk5v3b [ 0 ] , & rtB . mc0ac3mqpt3 . cpoh2looqz [ 0 ] , & rtB .
exx2sgg2c1 . cpoh2looqz [ 0 ] , & rtB . nwx4oddprh . cpoh2looqz [ 0 ] , & rtB
. ildclrdm44a . ljwteyu2qv [ 0 ] , & rtB . bosgivqpz4 . ljwteyu2qv [ 0 ] , &
rtB . d1lln4iu3m . ljwteyu2qv [ 0 ] , & rtB . o5wnfdweb1 [ 0 ] , & rtB .
e3or5hi53b [ 0 ] , & rtB . pkisk4c5w5 [ 0 ] , & rtP . Gain_Gain [ 0 ] , & rtP
. RateTransition2_X0 , & rtP . Unbuffer_ic , & rtP . Unbuffer1_ic , & rtP .
Unbuffer2_ic , & rtP . BalanceLatencies_DelayLength , & rtP .
BalanceLatencies_InitialCondition , & rtP .
BalanceLatencies_DelayLength_iqg5kwcyls , & rtP .
BalanceLatencies_InitialCondition_by3kggjded , & rtP .
BalanceLatencies_DelayLength_nzwuirigpx , & rtP .
BalanceLatencies_InitialCondition_gdswlhk2br , } ; static int32_T *
rtVarDimsAddrMap [ ] = { ( NULL ) } ;
#endif
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { {
"unsigned char" , "uint8_T" , 0 , 0 , sizeof ( uint8_T ) , SS_UINT8 , 0 , 0 }
, { "unsigned char" , "boolean_T" , 0 , 0 , sizeof ( boolean_T ) , SS_BOOLEAN
, 0 , 0 } } ;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static const rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_MATRIX_COL_MAJOR , 0 , 2 , 0 } , { rtwCAPI_MATRIX_COL_MAJOR , 2 , 2 ,
0 } , { rtwCAPI_SCALAR , 4 , 2 , 0 } , { rtwCAPI_MATRIX_COL_MAJOR , 6 , 2 , 0
} , { rtwCAPI_MATRIX_COL_MAJOR , 8 , 2 , 0 } , { rtwCAPI_VECTOR , 8 , 2 , 0 }
, { rtwCAPI_VECTOR , 10 , 2 , 0 } } ; static const uint_T rtDimensionArray [
] = { 176 , 240 , 176 , 120 , 1 , 1 , 240 , 176 , 42240 , 1 , 1 , 5 } ;
static const real_T rtcapiStoredFloats [ ] = { 0.041666666666666664 , 0.0 ,
1.0 , 9.8642676767676768E-7 } ; static const rtwCAPI_FixPtMap rtFixPtMap [ ]
= { { ( NULL ) , ( NULL ) , rtwCAPI_FIX_RESERVED , 0 , 0 , 0 } , { ( const
void * ) & rtcapiStoredFloats [ 2 ] , ( const void * ) & rtcapiStoredFloats [
1 ] , rtwCAPI_FIX_UNIFORM_SCALING , 1 , 0 , 0 } , { ( const void * ) &
rtcapiStoredFloats [ 2 ] , ( const void * ) & rtcapiStoredFloats [ 1 ] ,
rtwCAPI_FIX_UNIFORM_SCALING , 5 , 0 , 0 } } ; static const
rtwCAPI_SampleTimeMap rtSampleTimeMap [ ] = { { ( const void * ) &
rtcapiStoredFloats [ 0 ] , ( const void * ) & rtcapiStoredFloats [ 1 ] , 1 ,
0 } , { ( const void * ) & rtcapiStoredFloats [ 3 ] , ( const void * ) &
rtcapiStoredFloats [ 1 ] , 0 , 0 } , { ( const void * ) & rtcapiStoredFloats
[ 3 ] , ( const void * ) & rtcapiStoredFloats [ 1 ] , 0 , 1 } , { ( NULL ) ,
( NULL ) , - 1 , 0 } } ; static rtwCAPI_ModelMappingStaticInfo mmiStatic = {
{ rtBlockSignals , 43 , ( NULL ) , 0 , ( NULL ) , 0 } , { rtBlockParameters ,
11 , rtModelParameters , 0 } , { ( NULL ) , 0 } , { rtDataTypeMap ,
rtDimensionMap , rtFixPtMap , rtElementMap , rtSampleTimeMap ,
rtDimensionArray } , "float" , { 171571849U , 1712919735U , 3436261685U ,
2463775248U } , ( NULL ) , 0 , 0 } ; const rtwCAPI_ModelMappingStaticInfo *
fil_videosharp_sim_GetCAPIStaticMap ( ) { return & mmiStatic ; }
#ifndef HOST_CAPI_BUILD
void fil_videosharp_sim_InitializeDataMapInfo ( ) { rtwCAPI_SetVersion ( ( *
rt_dataMapInfoPtr ) . mmi , 1 ) ; rtwCAPI_SetStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , & mmiStatic ) ; rtwCAPI_SetLoggingStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ; rtwCAPI_SetDataAddressMap ( ( *
rt_dataMapInfoPtr ) . mmi , rtDataAddrMap ) ; rtwCAPI_SetVarDimsAddressMap (
( * rt_dataMapInfoPtr ) . mmi , rtVarDimsAddrMap ) ;
rtwCAPI_SetInstanceLoggingInfo ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArray ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( ( * rt_dataMapInfoPtr ) . mmi , 0 ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void fil_videosharp_sim_host_InitializeDataMapInfo (
fil_videosharp_sim_host_DataMapInfo_T * dataMap , const char * path ) {
rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ; rtwCAPI_SetStaticMap ( dataMap ->
mmi , & mmiStatic ) ; rtwCAPI_SetDataAddressMap ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , NULL ) ; rtwCAPI_SetPath (
dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetChildMMIArray ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 0 ) ; }
#ifdef __cplusplus
}
#endif
#endif
