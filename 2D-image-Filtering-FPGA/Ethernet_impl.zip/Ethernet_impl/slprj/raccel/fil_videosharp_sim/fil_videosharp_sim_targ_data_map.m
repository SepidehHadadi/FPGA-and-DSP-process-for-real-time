  function targMap = targDataMap(),

  ;%***********************
  ;% Create Parameter Map *
  ;%***********************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 1;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc paramMap
    ;%
    paramMap.nSections           = nTotSects;
    paramMap.sectIdxOffset       = sectIdxOffset;
      paramMap.sections(nTotSects) = dumSection; %prealloc
    paramMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtP)
    ;%
      section.nData     = 11;
      section.data(11)  = dumData; %prealloc
      
	  ;% rtP.BalanceLatencies_DelayLength
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtP.BalanceLatencies_InitialCondition
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtP.Unbuffer_ic
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtP.RateTransition2_X0
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtP.BalanceLatencies_DelayLength_iqg5kwcyls
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtP.BalanceLatencies_InitialCondition_by3kggjded
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtP.Unbuffer1_ic
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtP.BalanceLatencies_DelayLength_nzwuirigpx
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtP.BalanceLatencies_InitialCondition_gdswlhk2br
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtP.Unbuffer2_ic
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtP.Gain_Gain
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 10;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(1) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (parameter)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    paramMap.nTotData = nTotData;
    


  ;%**************************
  ;% Create Block Output Map *
  ;%**************************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 12;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc sigMap
    ;%
    sigMap.nSections           = nTotSects;
    sigMap.sectIdxOffset       = sectIdxOffset;
      sigMap.sections(nTotSects) = dumSection; %prealloc
    sigMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtB)
    ;%
      section.nData     = 23;
      section.data(23)  = dumData; %prealloc
      
	  ;% rtB.o5wnfdweb1
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.ph2ms1w2gh
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 42240;
	
	  ;% rtB.e3or5hi53b
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 42241;
	
	  ;% rtB.klxyj2wepv
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 84481;
	
	  ;% rtB.pkisk4c5w5
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 84482;
	
	  ;% rtB.grqrubiaoy
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 126722;
	
	  ;% rtB.i1hm2nlh3k
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 126723;
	
	  ;% rtB.ihuqv4edg3
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 126724;
	
	  ;% rtB.pn3popodna
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 126725;
	
	  ;% rtB.jf2vo3oy2f
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 126726;
	
	  ;% rtB.ibjdq010lc
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 168966;
	
	  ;% rtB.fnt5vk5v3b
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 211206;
	
	  ;% rtB.jb4bvh2jg0
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 253446;
	
	  ;% rtB.hpum20ybfk
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 295686;
	
	  ;% rtB.ei330voctg
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 337926;
	
	  ;% rtB.oidhnxlzrn
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 380166;
	
	  ;% rtB.ag2yqwewan
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 422406;
	
	  ;% rtB.autpxnj4rh
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 464646;
	
	  ;% rtB.iqyh2bdr3j
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 506886;
	
	  ;% rtB.g3tjfoemzo
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 549126;
	
	  ;% rtB.cedr240vrj
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 591366;
	
	  ;% rtB.bo4f3pqa3k
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 633606;
	
	  ;% rtB.jpemu0m5jb
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 654726;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(1) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% rtB.mqkcirpnav
	  section.data(1).logicalSrcIdx = 23;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.ajmukknkba
	  section.data(2).logicalSrcIdx = 24;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(2) = section;
      clear section
      
      section.nData     = 3;
      section.data(3)  = dumData; %prealloc
      
	  ;% rtB.bjwgh3zhq3
	  section.data(1).logicalSrcIdx = 25;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.k3o5ecaomc
	  section.data(2).logicalSrcIdx = 26;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtB.ndclinny1v
	  section.data(3).logicalSrcIdx = 27;
	  section.data(3).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(3) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtB.d1lln4iu3m.ljwteyu2qv
	  section.data(1).logicalSrcIdx = 28;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(4) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtB.bosgivqpz4.ljwteyu2qv
	  section.data(1).logicalSrcIdx = 29;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(5) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtB.ildclrdm44a.ljwteyu2qv
	  section.data(1).logicalSrcIdx = 30;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(6) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtB.nwx4oddprh.cpoh2looqz
	  section.data(1).logicalSrcIdx = 31;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(7) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtB.exx2sgg2c1.cpoh2looqz
	  section.data(1).logicalSrcIdx = 32;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(8) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtB.mc0ac3mqpt3.cpoh2looqz
	  section.data(1).logicalSrcIdx = 33;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(9) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtB.dehuj5bzxu.c4qjhbvh3g
	  section.data(1).logicalSrcIdx = 34;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(10) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtB.g3co00rhsr.c4qjhbvh3g
	  section.data(1).logicalSrcIdx = 35;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(11) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtB.ia4sifx1pp.c4qjhbvh3g
	  section.data(1).logicalSrcIdx = 36;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(12) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (signal)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    sigMap.nTotData = nTotData;
    


  ;%*******************
  ;% Create DWork Map *
  ;%*******************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 20;
    sectIdxOffset = 12;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc dworkMap
    ;%
    dworkMap.nSections           = nTotSects;
    dworkMap.sectIdxOffset       = sectIdxOffset;
      dworkMap.sections(nTotSects) = dumSection; %prealloc
    dworkMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtDW)
    ;%
      section.nData     = 9;
      section.data(9)  = dumData; %prealloc
      
	  ;% rtDW.cfvviahwgs
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.nf53pai11t
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.btv0brqgud
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtDW.gy3colbg2d
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtDW.nuoi2bpcqb
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 140;
	
	  ;% rtDW.kobal3a2ry
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 145;
	
	  ;% rtDW.kixhks45oc
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 156;
	
	  ;% rtDW.p3f52jnckb
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 157;
	
	  ;% rtDW.msngf5zymf
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 158;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(1) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.ewug0yyuyo.filcommon_PortInfo_Inputs
	  section.data(1).logicalSrcIdx = 9;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(2) = section;
      clear section
      
      section.nData     = 3;
      section.data(3)  = dumData; %prealloc
      
	  ;% rtDW.l0wyyt10jc
	  section.data(1).logicalSrcIdx = 10;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.k0hbnlu5x1
	  section.data(2).logicalSrcIdx = 11;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.ktnony3hbz
	  section.data(3).logicalSrcIdx = 12;
	  section.data(3).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(3) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.afib14q5zg
	  section.data(1).logicalSrcIdx = 13;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(4) = section;
      clear section
      
      section.nData     = 6;
      section.data(6)  = dumData; %prealloc
      
	  ;% rtDW.htr0gxofmj
	  section.data(1).logicalSrcIdx = 14;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.i3atoxqjmk
	  section.data(2).logicalSrcIdx = 15;
	  section.data(2).dtTransOffset = 42240;
	
	  ;% rtDW.fvq1rooxjr
	  section.data(3).logicalSrcIdx = 16;
	  section.data(3).dtTransOffset = 84480;
	
	  ;% rtDW.ovazadzx53
	  section.data(4).logicalSrcIdx = 17;
	  section.data(4).dtTransOffset = 126720;
	
	  ;% rtDW.ar2gdpszka
	  section.data(5).logicalSrcIdx = 18;
	  section.data(5).dtTransOffset = 168960;
	
	  ;% rtDW.b5fsf4ugkz
	  section.data(6).logicalSrcIdx = 19;
	  section.data(6).dtTransOffset = 211200;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(5) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.bsztjvk1v2
	  section.data(1).logicalSrcIdx = 20;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(6) = section;
      clear section
      
      section.nData     = 4;
      section.data(4)  = dumData; %prealloc
      
	  ;% rtDW.nzbtkt4pjn
	  section.data(1).logicalSrcIdx = 21;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.blvplwahnx
	  section.data(2).logicalSrcIdx = 22;
	  section.data(2).dtTransOffset = 84480;
	
	  ;% rtDW.dt1wcwu32n
	  section.data(3).logicalSrcIdx = 23;
	  section.data(3).dtTransOffset = 126720;
	
	  ;% rtDW.fstvboqg4t
	  section.data(4).logicalSrcIdx = 24;
	  section.data(4).dtTransOffset = 147840;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(7) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.arufmtcy3m
	  section.data(1).logicalSrcIdx = 25;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(8) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.d1lln4iu3m.lfya5jsxdb
	  section.data(1).logicalSrcIdx = 26;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(9) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.bosgivqpz4.lfya5jsxdb
	  section.data(1).logicalSrcIdx = 27;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(10) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.ildclrdm44a.lfya5jsxdb
	  section.data(1).logicalSrcIdx = 28;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(11) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.nwx4oddprh.bolnweqpxw
	  section.data(1).logicalSrcIdx = 29;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(12) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.nwx4oddprh.akoskppbih
	  section.data(1).logicalSrcIdx = 30;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(13) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.nwx4oddprh.nzofjgicqg
	  section.data(1).logicalSrcIdx = 31;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(14) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.exx2sgg2c1.bolnweqpxw
	  section.data(1).logicalSrcIdx = 32;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(15) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.exx2sgg2c1.akoskppbih
	  section.data(1).logicalSrcIdx = 33;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(16) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.exx2sgg2c1.nzofjgicqg
	  section.data(1).logicalSrcIdx = 34;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(17) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.mc0ac3mqpt3.bolnweqpxw
	  section.data(1).logicalSrcIdx = 35;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(18) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.mc0ac3mqpt3.akoskppbih
	  section.data(1).logicalSrcIdx = 36;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(19) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.mc0ac3mqpt3.nzofjgicqg
	  section.data(1).logicalSrcIdx = 37;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(20) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (dwork)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    dworkMap.nTotData = nTotData;
    


  ;%
  ;% Add individual maps to base struct.
  ;%

  targMap.paramMap  = paramMap;    
  targMap.signalMap = sigMap;
  targMap.dworkMap  = dworkMap;
  
  ;%
  ;% Add checksums to base struct.
  ;%


  targMap.checksum0 = 171571849;
  targMap.checksum1 = 1712919735;
  targMap.checksum2 = 3436261685;
  targMap.checksum3 = 2463775248;

